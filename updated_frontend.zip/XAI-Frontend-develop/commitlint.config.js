export const rules = {
    'custom-regex-rule': [
        2,
        'always',
        /^(feat|bug|fix|hotfix):\s.+\s\|\sAIE-(?:[1-9]\d{0,2})$/,
    ],
}
export const plugins = [
    {
        rules: {
            'custom-regex-rule': ({ raw }) => {
                const valid =
                    /^(feat|bug|fix|hotfix):\s.+\s\|\sAIE-(?:[1-9]\d{0,2})$/.test(
                        raw
                    )
                return [
                    valid,
                    'Commit message must match: (feat|bug|fix|hotfix): <desc> | AIE-<1-999>',
                ]
            },
        },
    },
]
