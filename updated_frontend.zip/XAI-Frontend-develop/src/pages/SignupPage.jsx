import {
    Box,
    Button,
    Card,
    CardContent,
    TextField,
    Typography,
    InputAdornment,
    IconButton,
    Avatar,
    Link as MuiLink,
} from '@mui/material'
import {
    Email,
    Lock,
    Person,
    Visibility,
    VisibilityOff,
    ArrowBack,
} from '@mui/icons-material'
import { useState, useEffect } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import {
    signupUser,
    clearSignupSuccess,
    clearAuthError,
} from '../store/authSlice'
import { showSuccessToast, showErrorToast } from '../utils/toastUtility'
import theme from '../theme'

const validateEmail = (email) => {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!regex.test(email)) return false
    if (email.includes('..')) return false
    const dotCount = (email.match(/\./g) || []).length
    if (dotCount > 2) return false
    if (!email.toLowerCase().endsWith('@cirruslabs.io')) return false

    return true
}

const SignupPage = () => {
    const navigate = useNavigate()
    const dispatch = useDispatch()

    const { signupSuccess, error } = useSelector((state) => state.auth)

    const [formData, setFormData] = useState({
        fullName: '',
        username: '',
        email: '',
        password: '',
    })
    const [showPassword, setShowPassword] = useState(false)
    const [passwordError, setPasswordError] = useState('')
    const [emailError, setEmailError] = useState('')
    const [usernameError, setUsernameError] = useState(false)

    // Password strength validation
    const validatePassword = (password) => {
        const regex =
            /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+{}[\]:;<>,.?~\\/-]).{8,}$/
        return regex.test(password)
    }

    const isFormValid =
        formData.fullName.trim() &&
        formData.username.trim() &&
        formData.email.trim() &&
        validateEmail(formData.email) &&
        formData.password &&
        validatePassword(formData.password)

    useEffect(() => {
        if (signupSuccess && !error) {
            dispatch(clearSignupSuccess())
            showSuccessToast('Signup successful! Please log in.')
            navigate('/login')
        } else if (error) {
            showErrorToast(error)
            dispatch(clearAuthError())
        }
    }, [signupSuccess, error, dispatch, navigate])

    const handleChange = (e) => {
        const { name, value } = e.target

        // Check for spaces
        if (/\s/.test(value)) {
            if (name === 'username') {
                setFormData((prev) => ({
                    ...prev,
                    [name]: value.replace(/\s/g, ''),
                }))
                setUsernameError('Spaces are not allowed')
                return
            }
            if (name === 'email') {
                setEmailError('Spaces are not allowed in email.')
                return
            }
            if (name === 'password') {
                setPasswordError('Spaces are not allowed in password.')
                return
            }
        } else {
            if (name === 'email') setEmailError('')
            if (name === 'password') setPasswordError('')
        }

        if (name === 'email') {
            if (!validateEmail(value)) {
                setEmailError('Please enter a valid email address.')
            } else {
                setEmailError('')
            }
        }

        if (name === 'password') {
            if (!validatePassword(value)) {
                setPasswordError(
                    'Password must be at least 8 characters, include an uppercase letter, a lowercase letter, a number, and a special character.'
                )
            } else {
                setPasswordError('')
            }
        }

        setFormData((prev) => ({
            ...prev,
            [name]: value,
        }))

        if (error) dispatch(clearAuthError())
    }

    const handleSignup = () => {
        const { fullName, email, username, password } = formData

        if (/\s/.test(email) || /\s/.test(username) || /\s/.test(password)) {
            showErrorToast('Spaces are not allowed in any field.')
            return
        }

        if (!validatePassword(password)) {
            setPasswordError(
                'Password must be at least 8 characters, include an uppercase and lowercase letter, a number, and a special character.'
            )
            return
        }

        dispatch(
            signupUser({
                name: fullName,
                email,
                username,
                password,
            })
        )
    }

    const togglePasswordVisibility = () => setShowPassword((prev) => !prev)
    const handleGoBack = () => navigate('/login')

    return (
        <Box
            display="flex"
            justifyContent="center"
            alignItems="center"
            minHeight="100vh"
            sx={{
                bgcolor: 'transparent',
                color: theme.palette.text.primary,
                boxShadow: theme.shadows[6],
                textAlign: 'center',
                overflow: 'hidden',
                position: 'relative',
                zIndex: 1,
                background: `linear-gradient(135deg, ${theme.palette.primary.dark} 0%, ${theme.palette.secondary.dark} 100%)`,
                '&::before': {
                    content: '""',
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    right: 0,
                    bottom: 0,
                    background: `repeating-linear-gradient(
                        45deg,
                        rgba(255,255,255,0.02) 0px,
                        rgba(255,255,255,0.02) 2px,
                        transparent 2px,
                        transparent 20px
                    ),
                    repeating-linear-gradient(
                        -45deg,
                        rgba(255,255,255,0.02) 0px,
                        rgba(255,255,255,0.02) 2px,
                        transparent 2px,
                        transparent 20px
                    )`,
                    opacity: 0.8,
                    zIndex: -1,
                },
            }}
        >
            <Card
                sx={{
                    width: 400,
                    borderRadius: 3,
                    boxShadow: 6,
                    maxWidth: '90%',
                }}
            >
                <CardContent sx={{ textAlign: 'center', position: 'relative' }}>
                    <IconButton
                        onClick={handleGoBack}
                        sx={{ position: 'absolute', left: 8, top: 8 }}
                        aria-label="Go back"
                    >
                        <ArrowBack />
                    </IconButton>

                    <Avatar
                        src="/logo-nav.png"
                        alt="XAI"
                        sx={{ width: '40%', height: '100%', mx: 'auto', mb: 3 }}
                        variant="rounded"
                    />

                    <Typography variant="h5" gutterBottom>
                        Create Account
                    </Typography>
                    <Typography variant="body2" color="text.secondary" mb={3}>
                        Join us to explore RAIA
                    </Typography>

                    <TextField
                        label={
                            <>
                                Full Name
                                <span style={{ color: 'red' }}> *</span>
                            </>
                        }
                        name="fullName"
                        fullWidth
                        margin="normal"
                        variant="outlined"
                        value={formData.fullName}
                        onChange={handleChange}
                        InputProps={{
                            startAdornment: (
                                <InputAdornment position="start">
                                    <Person />
                                </InputAdornment>
                            ),
                        }}
                    />

                    <TextField
                        label={
                            <>
                                Username<span style={{ color: 'red' }}> *</span>
                            </>
                        }
                        name="username"
                        fullWidth
                        margin="normal"
                        variant="outlined"
                        value={formData.username}
                        onChange={handleChange}
                        error={usernameError}
                        helperText={
                            usernameError ? 'Spaces are not allowed' : ''
                        }
                        InputProps={{
                            startAdornment: (
                                <InputAdornment position="start">
                                    <Person />
                                </InputAdornment>
                            ),
                        }}
                    />

                    <TextField
                        label={
                            <>
                                Email<span style={{ color: 'red' }}> *</span>
                            </>
                        }
                        name="email"
                        type="email"
                        fullWidth
                        margin="normal"
                        variant="outlined"
                        value={formData.email}
                        onChange={handleChange}
                        error={Boolean(emailError)}
                        helperText={emailError}
                        InputProps={{
                            startAdornment: (
                                <InputAdornment position="start">
                                    <Email />
                                </InputAdornment>
                            ),
                        }}
                    />

                    <TextField
                        label={
                            <>
                                Password<span style={{ color: 'red' }}> *</span>
                            </>
                        }
                        name="password"
                        type={showPassword ? 'text' : 'password'}
                        fullWidth
                        margin="normal"
                        variant="outlined"
                        sx={{
                            '& input::-ms-reveal': { display: 'none' },
                            '& input::-ms-clear': { display: 'none' },
                        }}
                        value={formData.password}
                        onChange={handleChange}
                        error={Boolean(passwordError)}
                        helperText={passwordError}
                        InputProps={{
                            startAdornment: (
                                <InputAdornment position="start">
                                    <Lock />
                                </InputAdornment>
                            ),
                            endAdornment: (
                                <InputAdornment position="end">
                                    <IconButton
                                        onClick={togglePasswordVisibility}
                                        edge="end"
                                    >
                                        {showPassword ? (
                                            <VisibilityOff />
                                        ) : (
                                            <Visibility />
                                        )}
                                    </IconButton>
                                </InputAdornment>
                            ),
                        }}
                    />

                    {error && (
                        <Typography
                            color="error"
                            variant="body2"
                            sx={{ mt: 1 }}
                        >
                            {error}
                        </Typography>
                    )}

                    <Button
                        variant="contained"
                        color="primary"
                        fullWidth
                        size="large"
                        sx={{ mt: 2, mb: 2 }}
                        onClick={handleSignup}
                        disabled={!isFormValid}
                    >
                        Sign Up
                    </Button>

                    <Typography variant="body2">
                        Already have an account?{' '}
                        <MuiLink
                            component={Link}
                            to="/login"
                            underline="hover"
                            color="primary"
                        >
                            Login
                        </MuiLink>
                    </Typography>
                </CardContent>
            </Card>
        </Box>
    )
}

export default SignupPage
