/* eslint-disable no-unused-vars */
import React, { useState, useEffect } from 'react'
import {
    Container,
    Grid,
    Paper,
    Typography,
    Box,
    Divider,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Chip,
    Button,
    CircularProgress,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    LinearProgress,
    Stack,
} from '@mui/material'
import { TabContext, TabList, TabPanel } from '@mui/lab'
import Tab from '@mui/material/Tab'
import PlayArrowIcon from '@mui/icons-material/PlayArrow'
import AssessmentIcon from '@mui/icons-material/Assessment'
import PreviewIcon from '@mui/icons-material/Preview'
import DownloadIcon from '@mui/icons-material/Download'
import LightbulbIcon from '@mui/icons-material/Lightbulb'
import {
    Radar,
    RadarChart,
    PolarGrid,
    PolarAngleAxis,
    PolarRadiusAxis,
    Legend,
    CartesianGrid,
} from 'recharts'

import {
    BarChart,
    Bar,
    XAxis,
    YAxis,
    Tooltip,
    ResponsiveContainer,
    PieChart,
    Pie,
    Cell,
} from 'recharts'

// --- Mock Data Imports ---
// Assuming these paths are correct relative to where this component is located
import performAnalysisData from '../mockdata/performanalysis.json' // Corrected import for performanalysis.json
import mitigationStrategiesData from '../mockdata/mitigation_strategies.json'
import listDatasetsData from '../mockdata/listdatasets.json'
import previewDatasetData from '../mockdata/preview_dataset.json' // Added preview_dataset.json import
import {
    Dashboard,
    DocumentScanner,
    Folder,
    InfoOutline,
    Launch,
} from '@mui/icons-material'
import SummaryLoaderPlaceholder from '../components/SummaryLoaderPlaceholder'
import axios from 'axios'
import { useSelector } from 'react-redux'
import ModelExplainibility from '../components/ModelExplanerDashboard'

// Helper for status color mapping (e.g., for disparity)
const getDisparityColor = (value) => {
    // These thresholds are examples; adjust based on domain knowledge
    if (Math.abs(value) > 0.1) return 'error' // High disparity
    if (Math.abs(value) > 0.03) return 'warning' // Moderate disparity
    return 'success' // Low disparity/good
}

// Helper for improvement percentage color mapping
const getImprovementColor = (percentage) => {
    if (percentage > 5) return 'success' // Significant positive improvement
    if (percentage > 0) return 'info' // Some positive improvement
    if (percentage < 0) return 'error' // Degradation or negative impact
    return 'default' // No change
}

const RegressionDashboard = ({
    setOpenSideBar,
    selectedProject,
    setSelectedProject,
    selectedSensitiveFeature,
}) => {
    const { token, user } = useSelector((state) => state?.auth)
    const projectList = useSelector((state) => state.driftConfig.projectList)
    const { regressionAnalysis, regressionModelExplainibility, loading } =
        useSelector((state) => state.regression)
    const { datasets } = useSelector((state) => state.fairness)
    const { features, metrics, llm_analysis_report, overview, plots } =
        regressionAnalysis || {}

    const [selectedTab, setSelectedTab] = useState('overview')
    const [htmlBlobUrl, setHtmlBlobUrl] = useState(null)
    const [selectedAttribute, setSelectedAttribute] = useState(
        performAnalysisData?.features?.[0] || 'Age_Group'
    )
    const [selectedTargetColumn, setSelectedTargetColumn] = useState(
        previewDatasetData?.columns?.find((col) =>
            col.includes('Performance')
        ) || 'Performance_Score'
    )
    const [selectedMitigationStrategy, setSelectedMitigationStrategy] =
        useState(
            mitigationStrategiesData?.strategies?.[0]?.value ||
                'exponentiated_gradient'
        )
    const [selectedDataset, setSelectedDataset] = useState(
        listDatasetsData?.files?.[0]?.file_name || 'ref_biased_age.csv'
    )

    const [llmExplanation, setLlmExplanation] = useState('')
    const [isLlmLoading, setIsLlmLoading] = useState(false)
    const [isModalOpen, setIsModalOpen] = useState(false)

    // Extract data for the currently selected sensitive attribute
    const currentAttributeMetrics =
        performAnalysisData?.metrics?.[selectedAttribute] || {}
    const llmAnalysisReport = llm_analysis_report || ''

    // Prepare data for the comparison bar charts (Before vs After Mitigation)
    const prepareChartData = (beforeData, afterData, metricKey) => {
        const data = []
        for (const group in beforeData) {
            data.push({
                name: group,
                'Before Mitigation': beforeData[group][metricKey],
                'After Mitigation': afterData[group][metricKey],
            })
        }
        return data
    }

    const accuracyChartData = prepareChartData(
        currentAttributeMetrics.group_performance_before,
        currentAttributeMetrics.group_performance_after,
        'accuracy_score'
    )
    const selectionRateChartData = prepareChartData(
        currentAttributeMetrics.group_performance_before,
        currentAttributeMetrics.group_performance_after,
        'selection_rate'
    )
    const tprChartData = prepareChartData(
        currentAttributeMetrics.group_performance_before,
        currentAttributeMetrics.group_performance_after,
        'tpr'
    )
    const fprChartData = prepareChartData(
        currentAttributeMetrics.group_performance_before,
        currentAttributeMetrics.group_performance_after,
        'fpr'
    )

    const grpWisePerfornameChartData = (data) =>
        Object.entries(data).map(([group, beforeMetrics]) => {
            const afterMetrics =
                metrics[features[0]].group_performance_after?.[group] || {}

            return {
                group,
                'Accuracy (Before)': beforeMetrics.accuracy_score || 0,
                'Accuracy (After)': afterMetrics.accuracy_score || 0,
                'Selection Rate (Before)': beforeMetrics.selection_rate || 0,
                'Selection Rate (After)': afterMetrics.selection_rate || 0,
                'TPR (Before)': beforeMetrics.tpr || 0,
                'TPR (After)': afterMetrics.tpr || 0,
                'FPR (Before)': beforeMetrics.fpr || 0,
                'FPR (After)': afterMetrics.fpr || 0,
            }
        })

    const radarChartData = [
        {
            metric: 'Accuracy',
            Before: accuracyChartData[0]?.['Before Mitigation'] || 0,
            After: accuracyChartData[0]?.['After Mitigation'] || 0,
        },
        {
            metric: 'Selection Rate',
            Before: selectionRateChartData[0]?.['Before Mitigation'] || 0,
            After: selectionRateChartData[0]?.['After Mitigation'] || 0,
        },
        {
            metric: 'TPR',
            Before: tprChartData[0]?.['Before Mitigation'] || 0,
            After: tprChartData[0]?.['After Mitigation'] || 0,
        },
        {
            metric: 'FPR',
            Before: fprChartData[0]?.['Before Mitigation'] || 0,
            After: fprChartData[0]?.['After Mitigation'] || 0,
        },
    ]

    // Handle LLM explanation
    const handleExplainWithAI = async () => {
        setIsLlmLoading(true)
        setIsModalOpen(true)
        try {
            const prompt = `Analyze the following regression analysis report and provide a concise, easy-to-understand executive summary, highlighting key biases, their impact, and the overall effectiveness of the mitigation applied. Also, suggest the most appropriate next steps based on the report.
            \n\n${llmAnalysisReport}`

            // Placeholder for API call. In a real application, this would call a backend.
            // For now, it simulates a delay and provides a simplified response.
            await new Promise((resolve) => setTimeout(resolve, 2000)) // Simulate API call delay
            setLlmExplanation(
                `AI-Generated Explanation (Simulated):\n\nBased on the analysis, the model shows significant regression disparities primarily affecting the '${selectedAttribute}' group, particularly 'Senior' individuals. The 'demographic_parity' and 'equalized_odds' metrics indicate notable bias before mitigation.\n\nWhile the 'exponentiated_gradient' mitigation strategy has shown some positive impact, reducing disparities in metrics like demographic parity and equalized odds by approximately ${Math.abs(((currentAttributeMetrics.overall_regression_metrics_before?.demographic_parity - currentAttributeMetrics.overall_regression_metrics_after?.demographic_parity) / currentAttributeMetrics.overall_regression_metrics_before?.demographic_parity) * 100).toFixed(2) || 0}% and ${Math.abs(((currentAttributeMetrics.overall_regression_metrics_before?.equalized_odds - currentAttributeMetrics.overall_regression_metrics_after?.equalized_odds) / currentAttributeMetrics.overall_regression_metrics_before?.equalized_odds) * 100).toFixed(2) || 0}% respectively, further action is required to achieve full compliance.\n\n**Key Findings:**\n* Accuracy remains lower for the 'Senior' group even after mitigation.\n* Selection rate disparities persist, indicating unequal treatment or opportunity.\n\n**Most Appropriate Next Step:**\nFocus on **Pre-processing techniques** (e.g., Reweighing or Data Augmentation). The persistent accuracy gap suggests fundamental issues in the training data representation. Addressing bias at the data source level is often more effective for significant and lasting improvements. This will help address root causes rather than just symptoms of bias. Additional in-processing or post-processing fine-tuning can follow if needed.`
            )
        } catch (error) {
            console.error('Error calling LLM API:', error)
            setLlmExplanation(
                'An error occurred while fetching the explanation. Please check console for details.'
            )
        } finally {
            setIsLlmLoading(false)
        }
    }

    // Helper to render markdown content
    const renderMarkdown = (markdownText) => {
        let html = markdownText
            // Headings
            .replace(/^### (.*$)/gim, '<h4 class="md-h4">$1</h4>')
            .replace(/^## (.*$)/gim, '<h3 class="md-h3">$1</h3>')
            .replace(/^# (.*$)/gim, '<h2 class="md-h2">$1</h2>')

            // Lists
            .replace(/^\* (.*$)/gim, '<li>$1</li>')
            .replace(/^- (.*$)/gim, '<li>$1</li>')

            // Bold & Italic
            .replace(/\*\*(.*?)\*\*/gim, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/gim, '<em>$1</em>')

            // Inline code
            .replace(/`([^`]+)`/gim, '<code class="md-code-inline">$1</code>')

            // Paragraphs (wrap isolated text blocks)
            .replace(
                /^(?!<h|<ul|<li|<code|<strong|<em|<p|<blockquote)(.+)$/gim,
                '<p class="md-paragraph">$1</p>'
            )

        // Wrap <li> blocks in <ul> only once
        html = html.replace(/(<li>.*?<\/li>)/gims, '<ul class="md-ul">$1</ul>')

        return (
            <div
                className="markdown-container"
                dangerouslySetInnerHTML={{ __html: html }}
            />
        )
    }

    const handleDeleteProject = (projectId) => {
        const confirmDelete = window.confirm(
            'Are you sure you want to delete this project?'
        )
        if (!confirmDelete) return

        // Update state
        const updatedProjects = projectList.filter(
            (p) => p.timestamp !== projectId
        )
    }

    useEffect(() => {
        if (regressionAnalysis && regressionAnalysis?.evidently_report_html) {
            const blob = new Blob([regressionAnalysis?.evidently_report_html], {
                type: 'text/html',
            })
            const url = URL.createObjectURL(blob)
            setHtmlBlobUrl(url)
        }
    }, [regressionAnalysis])
    if (loading) return <SummaryLoaderPlaceholder />
    if (
        regressionModelExplainibility &&
        regressionModelExplainibility?.explainer_url
    )
        return <ModelExplainibility />

    if (!regressionAnalysis) {
        return (
            <Container
                maxWidth="xl"
                sx={{
                    mt: 4,
                    mb: 4,
                    fontFamily: 'Inter, sans-serif',
                    '& .MuiPaper-root': {
                        boxShadow: '0px 1px 3px rgba(0, 0, 0, 0.1)',
                    },
                }}
            >
                {/* Page Header */}
                <Box sx={{ mb: 4 }}>
                    <Typography
                        variant="h4"
                        sx={{ fontWeight: 600, mb: 1, color: '#232f3e' }}
                    >
                        AI regression Analysis Platform
                    </Typography>
                    <Typography
                        variant="body1"
                        sx={{ color: 'text.secondary' }}
                    >
                        Evaluate model performance across different demographic
                        groups to assess regression and identify potential
                        biases.{' '}
                        <Button
                            // onClick={() => setShowDescription(true)}
                            variant="text"
                            color="primary.dark"
                            sx={{ fontSize: '1rem', padding: 0 }}
                        >
                            Learn More
                            <InfoOutline
                                sx={{
                                    fontSize: '1rem',
                                    ml: '4px',
                                }}
                            />
                        </Button>
                    </Typography>
                </Box>
                <Box>
                    {datasets && datasets?.regression?.files?.length > 0 ? (
                        <Box
                            sx={{
                                mt: 2,
                                display: 'flex',
                                flexDirection: 'column',
                                overflowX: 'auto',
                                gap: 2,
                                pb: 1,
                                width: '100%',
                            }}
                        >
                            <Typography>Files</Typography>
                            {datasets?.regression?.files?.map((project, i) => (
                                <Paper
                                    key={i}
                                    elevation={1}
                                    sx={{
                                        minWidth: 300,
                                        px: 3,
                                        py: 2,
                                        borderRadius: 2,
                                        display: 'flex',
                                        flexDirection: 'row',
                                        alignItems: 'center',
                                        justifyContent: 'space-between',
                                        border: '1px solid #e0e0e0',
                                        position: 'relative',
                                    }}
                                >
                                    <Box
                                        sx={{
                                            display: 'flex',
                                            alignItems: 'center',
                                            gap: 1,
                                        }}
                                    >
                                        <Dashboard
                                            sx={{
                                                color: 'green',
                                                fontSize: '1.6rem',
                                            }}
                                        />
                                        <Typography
                                            variant="subtitle1"
                                            fontWeight={600}
                                        >
                                            {project.file_name}
                                        </Typography>
                                    </Box>

                                    <Box
                                        sx={{
                                            display: 'flex',
                                            justifyContent: 'flex-end',
                                            gap: 1,
                                        }}
                                    >
                                        <Button
                                            variant="outlined"
                                            // onClick={() =>
                                            //     startAnalysisHandler(project)
                                            // }
                                            disabled
                                            sx={{ color: 'primary.dark' }}
                                        >
                                            View Details
                                            <Launch fontSize="small" />
                                        </Button>
                                    </Box>
                                </Paper>
                            ))}
                        </Box>
                    ) : (
                        <Box
                            sx={{
                                border: '1px dashed #ccc',
                                borderRadius: 2,
                                p: 4,
                                mt: 4,
                                textAlign: 'center',
                                backgroundColor: '#fafafa',
                            }}
                        >
                            <Typography
                                variant="subtitle1"
                                fontWeight={500}
                                gutterBottom
                            >
                                No Past Analysis Found
                            </Typography>
                            <Typography
                                variant="body2"
                                color="text.secondary"
                                sx={{ maxWidth: 500, margin: '0 auto' }}
                            >
                                You haven’t created any drift monitoring
                                projects yet. Create one to begin analyzing
                                model stability over time.
                            </Typography>
                            <Button
                                variant="contained"
                                sx={{ mt: 3 }}
                                onClick={() => setOpenSideBar(true)}
                            >
                                Create Analysis
                            </Button>
                        </Box>
                    )}
                </Box>
            </Container>
        )
    }

    return (
        <Container
            maxWidth="xl"
            sx={{
                mt: 4,
                mb: 4,
                fontFamily: 'Inter, sans-serif',
                '& .MuiPaper-root': {
                    boxShadow: '0px 1px 3px rgba(0, 0, 0, 0.1)',
                },
            }}
        >
            {/* Page Header */}
            <Box sx={{ mb: 4 }}>
                <Typography
                    variant="h4"
                    sx={{ fontWeight: 600, mb: 1, color: '#232f3e' }}
                >
                    AI regression Analysis Platform
                </Typography>
                <Typography variant="body1" sx={{ color: 'text.secondary' }}>
                    Evaluate model performance across different demographic
                    groups to assess regression and identify potential biases.{' '}
                    <Button
                        // onClick={() => setShowDescription(true)}
                        variant="text"
                        color="primary.dark"
                        sx={{ fontSize: '1rem', padding: 0 }}
                    >
                        Learn More
                        <InfoOutline
                            sx={{
                                fontSize: '1rem',
                                ml: '4px',
                            }}
                        />
                    </Button>
                </Typography>
            </Box>
            <iframe
                src={htmlBlobUrl}
                title="Drift Report"
                style={{
                    width: '100%',
                    height: '100vh',
                    border: 'none',
                }}
            />
        </Container>
    )
}

export default RegressionDashboard
