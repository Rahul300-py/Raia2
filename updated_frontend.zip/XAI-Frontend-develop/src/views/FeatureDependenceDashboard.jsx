// src/views/FeatureDependenceDashboard.jsx
import React, { useState } from 'react'
import {
    Box,
    Typography,
    Button,
    Select,
    MenuItem,
    FormControl,
    InputLabel,
    Stack,
    Paper,
} from '@mui/material'
import PlayArrowIcon from '@mui/icons-material/PlayArrow'

// Mock data for features
const MOCK_TITANIC_FEATURES = [
    'Sex',
    'PassengerClass',
    'Age',
    'Fare',
    'Embarked',
    'SibSp',
    'Parch',
    'Deck',
]

// Mock data for Feature Dependence (e.g., PDP for Age)
const MOCK_AGE_PDP_DATA = [
    { age: 0, probability: 0.3 },
    { age: 10, probability: 0.5 },
    { age: 20, probability: 0.4 },
    { age: 30, probability: 0.35 },
    { age: 40, probability: 0.3 },
    { age: 50, probability: 0.25 },
    { age: 60, probability: 0.2 },
    { age: 70, probability: 0.15 },
    { age: 80, probability: 0.1 },
]

const FeatureDependenceDashboard = ({
    setOpenSideBar,
    setSelectedProject,
    selectedProject,
    setShowChatBot,
}) => {
    const [dependencyFeature, setDependencyFeature] = useState('Age')

    return (
        <Box mt={12}>
            <Box
                sx={{
                    display: 'flex',
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                }}
            >
                <Typography variant="h5" sx={{ fontWeight: 600, mb: 3 }}>
                    Feature Dependence Plots
                </Typography>
                <Button
                    variant="contained"
                    startIcon={<PlayArrowIcon />}
                    onClick={() => setShowChatBot && setShowChatBot(true)}
                    sx={{ mb: 2 }}
                >
                    Explain with AI
                </Button>
            </Box>

            <Typography variant="body1" sx={{ color: 'text.secondary', mb: 3 }}>
                Visualize how a single feature impacts the model's prediction on
                average.
            </Typography>

            <FormControl
                variant="outlined"
                size="small"
                sx={{ minWidth: 250, mb: 4 }}
            >
                <InputLabel id="dependency-feature-label">
                    Select Feature
                </InputLabel>
                <Select
                    labelId="dependency-feature-label"
                    value={dependencyFeature}
                    onChange={(e) => setDependencyFeature(e.target.value)}
                    label="Select Feature"
                >
                    {MOCK_TITANIC_FEATURES.map((f) => (
                        <MenuItem key={f} value={f}>
                            {f}
                        </MenuItem>
                    ))}
                </Select>
            </FormControl>

            <Paper
                variant="outlined"
                sx={{
                    p: 3,
                    borderRadius: '8px',
                    minHeight: '400px',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: 'text.secondary',
                    bgcolor: 'grey.50',
                }}
            >
                <Typography variant="h6" sx={{ mb: 2 }}>
                    Partial Dependence Plot (PDP) / Individual Conditional
                    Expectation (ICE) for "{dependencyFeature}"
                </Typography>

                <Box
                    sx={{
                        width: '80%',
                        height: '300px',
                        border: '1px dashed grey',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                    }}
                >
                    <Typography variant="caption" color="text.disabled">
                        Interactive Line/Scatter Plot showing average prediction
                        as feature value changes.
                        {dependencyFeature === 'Age' && (
                            <Stack
                                direction="row"
                                justifyContent="space-around"
                                sx={{ width: '100%', mt: 2 }}
                            >
                                {MOCK_AGE_PDP_DATA.map((d, i) => (
                                    <Stack key={i} alignItems="center">
                                        <Box
                                            sx={{
                                                width: 10,
                                                height: `${d.probability * 150}px`,
                                                bgcolor: 'primary.light',
                                                border: '1px solid primary.main',
                                                borderRadius: '4px',
                                            }}
                                        />
                                        <Typography
                                            variant="caption"
                                            sx={{ mt: 0.5 }}
                                        >
                                            {d.age}
                                        </Typography>
                                    </Stack>
                                ))}
                            </Stack>
                        )}
                    </Typography>
                </Box>

                <Typography variant="body2" sx={{ mt: 2, textAlign: 'center' }}>
                    Shows the marginal effect of a feature on the predicted
                    outcome.
                </Typography>
            </Paper>
        </Box>
    )
}

export default FeatureDependenceDashboard
