// src/views/IndividualPredictionsDashboard.jsx
import React, { useState } from 'react'
import {
    Box,
    Typography,
    Button,
    Select,
    MenuItem,
    FormControl,
    InputLabel,
    Stack,
    Paper,
    Divider,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
} from '@mui/material'
import PlayArrowIcon from '@mui/icons-material/PlayArrow'

// Mock data for individual prediction
const MOCK_INDIVIDUAL_PREDICTION = {
    predicted_class: 'Survived',
    probability: 0.88,
    base_value: 0.5,
    explanation_values: [
        { feature: 'Sex=female', value: 0.45, type: 'positive' },
        { feature: 'PassengerClass=1st', value: 0.2, type: 'positive' },
        { feature: 'Age=28', value: 0.1, type: 'positive' },
        { feature: 'Fare=71.28', value: 0.05, type: 'positive' },
        { feature: 'Embarked=C', value: 0.02, type: 'positive' },
        { feature: 'Parch=0', value: -0.03, type: 'negative' },
        { feature: 'SibSp=1', value: -0.05, type: 'negative' },
        { feature: 'Deck=C', value: -0.08, type: 'negative' },
    ].sort((a, b) => Math.abs(b.value) - Math.abs(a.value)),
    final_prediction_sum:
        0.5 + 0.45 + 0.2 + 0.1 + 0.05 + 0.02 - 0.03 - 0.05 - 0.08,
}

const IndividualPredictionsDashboard = ({
    setOpenSideBar,
    setSelectedProject,
    selectedProject,
    setShowChatBot,
}) => {
    const [selectedIndividual, setSelectedIndividual] =
        useState('Passenger 1234')

    return (
        <Box mt={12}>
            <Box
                sx={{
                    display: 'flex',
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                }}
            >
                <Typography variant="h5" sx={{ fontWeight: 600, mb: 3 }}>
                    Individual Prediction Explanations
                </Typography>
                <Button
                    variant="contained"
                    startIcon={<PlayArrowIcon />}
                    onClick={() => setShowChatBot && setShowChatBot(true)}
                    sx={{ mb: 2 }}
                >
                    Explain with AI
                </Button>
            </Box>

            <Typography variant="body1" sx={{ color: 'text.secondary', mb: 3 }}>
                Understand why the model made a specific prediction for a single
                passenger.
            </Typography>

            <FormControl
                variant="outlined"
                size="small"
                sx={{ minWidth: 250, mb: 4 }}
            >
                <InputLabel id="select-individual-label">
                    Select Passenger ID
                </InputLabel>
                <Select
                    labelId="select-individual-label"
                    value={selectedIndividual}
                    onChange={(e) => setSelectedIndividual(e.target.value)}
                    label="Select Passenger ID"
                >
                    <MenuItem value="Passenger 1234">
                        Passenger 1234 (Survived)
                    </MenuItem>
                    <MenuItem value="Passenger 5678">
                        Passenger 5678 (Did Not Survive)
                    </MenuItem>
                </Select>
            </FormControl>

            <Paper variant="outlined" sx={{ p: 3, borderRadius: '8px' }}>
                <Typography variant="h6" sx={{ mb: 2 }}>
                    Prediction for {selectedIndividual}:{' '}
                    <Box
                        component="span"
                        sx={{
                            color: 'primary.main',
                            fontWeight: 'bold',
                        }}
                    >
                        {MOCK_INDIVIDUAL_PREDICTION.predicted_class}
                    </Box>{' '}
                    (Probability:{' '}
                    {(MOCK_INDIVIDUAL_PREDICTION.probability * 100).toFixed(1)}
                    %)
                </Typography>

                <Divider sx={{ my: 2 }} />

                <Typography variant="body1" sx={{ mb: 2 }}>
                    Feature contributions to this prediction (SHAP/LIME
                    Waterfall Plot):
                </Typography>

                <Box
                    sx={{
                        minHeight: '350px',
                        border: '1px dashed grey',
                        borderRadius: '8px',
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        justifyContent: 'center',
                        color: 'text.secondary',
                        mb: 2,
                        p: 2,
                        bgcolor: 'grey.50',
                    }}
                >
                    <Typography variant="h6" sx={{ mb: 2 }}>
                        Waterfall Plot Placeholder
                    </Typography>

                    <Box
                        sx={{
                            width: '90%',
                            display: 'flex',
                            flexDirection: 'column',
                            alignItems: 'center',
                        }}
                    >
                        <Typography
                            variant="caption"
                            sx={{ alignSelf: 'flex-start', mb: 1 }}
                        >
                            Base Value: {MOCK_INDIVIDUAL_PREDICTION.base_value}
                        </Typography>

                        {MOCK_INDIVIDUAL_PREDICTION.explanation_values.map(
                            (item, index) => (
                                <Stack
                                    key={index}
                                    direction="row"
                                    alignItems="center"
                                    sx={{ width: '100%', mb: 0.5 }}
                                >
                                    <Typography
                                        variant="body2"
                                        sx={{
                                            minWidth: '150px',
                                            textAlign: 'right',
                                            mr: 1,
                                            color:
                                                item.type === 'positive'
                                                    ? 'success.dark'
                                                    : 'error.dark',
                                        }}
                                    >
                                        {item.feature}
                                    </Typography>
                                    <Box
                                        sx={{
                                            height: '15px',
                                            width: `${Math.abs(item.value) * 200}%`,
                                            bgcolor:
                                                item.type === 'positive'
                                                    ? 'success.light'
                                                    : 'error.light',
                                            border: `1px solid ${
                                                item.type === 'positive'
                                                    ? 'success.main'
                                                    : 'error.main'
                                            }`,
                                            borderRadius: '4px',
                                            ml:
                                                item.type === 'positive'
                                                    ? 0
                                                    : `${
                                                          (MOCK_INDIVIDUAL_PREDICTION.base_value +
                                                              0.1) *
                                                          200
                                                      }%`,
                                            mr:
                                                item.type === 'negative'
                                                    ? 0
                                                    : `${
                                                          (MOCK_INDIVIDUAL_PREDICTION.base_value +
                                                              0.1) *
                                                          200
                                                      }%`,
                                        }}
                                    />
                                    <Typography
                                        variant="caption"
                                        sx={{
                                            ml: 1,
                                            color: 'text.secondary',
                                        }}
                                    >
                                        {item.value.toFixed(3)}
                                    </Typography>
                                </Stack>
                            )
                        )}

                        <Typography
                            variant="caption"
                            sx={{ alignSelf: 'flex-start', mt: 1 }}
                        >
                            Final Prediction:{' '}
                            {MOCK_INDIVIDUAL_PREDICTION.final_prediction_sum.toFixed(
                                3
                            )}
                        </Typography>
                    </Box>

                    <Typography
                        variant="caption"
                        color="text.disabled"
                        sx={{ mt: 2 }}
                    >
                        (Actual Waterfall Charts are more complex with charting
                        libraries like Plotly.js)
                    </Typography>
                </Box>

                <TableContainer component={Paper} elevation={0} sx={{ mt: 3 }}>
                    <Table size="small">
                        <TableHead>
                            <TableRow sx={{ bgcolor: 'grey.100' }}>
                                <TableCell sx={{ fontWeight: 'bold' }}>
                                    Feature
                                </TableCell>
                                <TableCell sx={{ fontWeight: 'bold' }}>
                                    Contribution
                                </TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {MOCK_INDIVIDUAL_PREDICTION.explanation_values.map(
                                (f, i) => (
                                    <TableRow key={i}>
                                        <TableCell>{f.feature}</TableCell>
                                        <TableCell
                                            sx={{
                                                color:
                                                    f.type === 'positive'
                                                        ? 'success.main'
                                                        : 'error.main',
                                            }}
                                        >
                                            {f.value.toFixed(3)} ({f.type})
                                        </TableCell>
                                    </TableRow>
                                )
                            )}
                        </TableBody>
                    </Table>
                </TableContainer>
            </Paper>
        </Box>
    )
}

export default IndividualPredictionsDashboard
