// src/views/DecisionTreesDashboard.jsx
import React from 'react'
import { Box, Typography, Button, Stack, Paper } from '@mui/material'
import PlayArrowIcon from '@mui/icons-material/PlayArrow'

const DecisionTreesDashboard = ({
    setOpenSideBar,
    setSelectedProject,
    selectedProject,
    setShowChatBot,
}) => {
    return (
        <Box mt={12}>
            <Box
                sx={{
                    display: 'flex',
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                }}
            >
                <Typography variant="h5" sx={{ fontWeight: 600, mb: 3 }}>
                    Decision Tree Visualization
                </Typography>
                <Button
                    variant="contained"
                    startIcon={<PlayArrowIcon />}
                    onClick={() => setShowChatBot && setShowChatBot(true)}
                    sx={{ mb: 2 }}
                >
                    Explain with AI
                </Button>
            </Box>

            <Typography variant="body1" sx={{ color: 'text.secondary', mb: 3 }}>
                If a tree-based model was used, visualize the decision path and
                rules.
            </Typography>

            <Paper
                variant="outlined"
                sx={{
                    p: 3,
                    borderRadius: '8px',
                    minHeight: '500px',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: 'text.secondary',
                    bgcolor: 'grey.50',
                }}
            >
                <Typography variant="h6" sx={{ mb: 2 }}>
                    Decision Tree Graph Placeholder
                </Typography>
                <Box
                    sx={{
                        width: '90%',
                        height: '400px',
                        border: '1px dashed grey',
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        justifyContent: 'flex-start',
                        overflow: 'auto',
                        p: 2,
                    }}
                >
                    {/* Simplified Tree Nodes */}
                    <Box
                        sx={{
                            bgcolor: 'primary.light',
                            border: '1px solid primary.main',
                            p: 1,
                            borderRadius: '8px',
                            mb: 1,
                        }}
                    >
                        <Typography variant="body2" sx={{ fontWeight: 'bold' }}>
                            Root Node: Sex {'<='} 0.5 (Male)
                        </Typography>
                        <Typography variant="caption">
                            Samples: 891, Value: [549, 342]
                        </Typography>
                    </Box>
                    <Box
                        sx={{
                            width: '2px',
                            height: '20px',
                            bgcolor: 'grey.400',
                        }}
                    />
                    <Stack
                        direction="row"
                        spacing={4}
                        sx={{
                            width: '100%',
                            justifyContent: 'space-around',
                        }}
                    >
                        <Box
                            sx={{
                                bgcolor: 'info.light',
                                border: '1px solid info.main',
                                p: 1,
                                borderRadius: '8px',
                                width: '45%',
                            }}
                        >
                            <Typography
                                variant="body2"
                                sx={{ fontWeight: 'bold' }}
                            >
                                True: Class {'<='} 2.5
                            </Typography>
                            <Typography variant="caption">
                                Samples: 450, Value: [400, 50]
                            </Typography>
                        </Box>
                        <Box
                            sx={{
                                bgcolor: 'warning.light',
                                border: '1px solid warning.main',
                                p: 1,
                                borderRadius: '8px',
                                width: '45%',
                            }}
                        >
                            <Typography
                                variant="body2"
                                sx={{ fontWeight: 'bold' }}
                            >
                                False: Sex {'>'} 0.5 (Female)
                            </Typography>
                            <Typography variant="caption">
                                Samples: 441, Value: [149, 292]
                            </Typography>
                        </Box>
                    </Stack>
                    <Typography
                        variant="caption"
                        color="text.disabled"
                        sx={{ mt: 2 }}
                    >
                        (Actual tree visualizations are interactive and complex,
                        requiring libraries like D3.js or specialized tools.)
                    </Typography>
                </Box>
            </Paper>
        </Box>
    )
}

export default DecisionTreesDashboard
