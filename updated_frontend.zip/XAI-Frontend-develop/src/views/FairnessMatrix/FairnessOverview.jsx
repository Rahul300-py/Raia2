/* eslint-disable no-unused-vars */
import React, { useState } from 'react'
import { useSelector } from 'react-redux'

import {
    Container,
    Grid,
    Paper,
    Typography,
    Box,
    Divider,
    Button,
} from '@mui/material'
import { TabPanel } from '@mui/lab'
import LightbulbIcon from '@mui/icons-material/Lightbulb'

function FairnessOverview({ selectedTargetColumn, handleExplainWithAI }) {
    const { fairnessAnalysis, loading } = useSelector((state) => state.fairness)
    const {
        metrics = {},
        overview,
        llm_analysis_report: llmAnalysisReport,
    } = fairnessAnalysis || {}

    const [selectedTab, setSelectedTab] = useState('overview')
    const [selectedAttribute, setSelectedAttribute] = useState(
        Object.keys(metrics)[0] || ''
    )
    const [isLlmLoading, setIsLlmLoading] = useState(false)

    // Helper to render markdown content
    const renderMarkdown = (markdownText) => {
        let html = markdownText
            .replace(/^### (.*$)/gim, '<h4 class="md-h4">$1</h4>')
            .replace(/^## (.*$)/gim, '<h3 class="md-h3">$1</h3>')
            .replace(/^# (.*$)/gim, '<h2 class="md-h2">$1</h2>')
            .replace(/^\* (.*$)/gim, '<li>$1</li>')
            .replace(/^- (.*$)/gim, '<li>$1</li>')
            .replace(/\*\*(.*?)\*\*/gim, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/gim, '<em>$1</em>')
            .replace(/`([^`]+)`/gim, '<code class="md-code-inline">$1</code>')
            .replace(
                /^(?!<h|<ul|<li|<code|<strong|<em|<p|<blockquote)(.+)$/gim,
                '<p class="md-paragraph">$1</p>'
            )
        html = html.replace(/(<li>.*?<\/li>)/gims, '<ul class="md-ul">$1</ul>')

        return (
            <div
                className="markdown-container"
                dangerouslySetInnerHTML={{ __html: html }}
            />
        )
    }

    return (
        <TabPanel value="overview" sx={{ p: 0 }}>
            <Grid container spacing={3}>
                {/* Executive Summary */}
                <Grid item xs={12}>
                    <Paper
                        elevation={0}
                        sx={{
                            p: 3,
                            borderRadius: '8px',
                            border: '1px solid #e0e0e0',
                        }}
                    >
                        <Typography
                            variant="h5"
                            sx={{ mb: 2, fontWeight: 600, color: '#232f3e' }}
                        >
                            Executive Summary
                        </Typography>
                        <Divider sx={{ mb: 2, borderColor: '#f0f2f2' }} />
                        <Grid container spacing={2}>
                            <Grid item xs={12} sm={6} md={3}>
                                <Typography
                                    variant="subtitle1"
                                    color="text.secondary"
                                >
                                    Mitigation Strategy
                                </Typography>
                                <Typography variant="h6">
                                    {overview?.mitigation_strategy_used ||
                                        'N/A'}
                                </Typography>
                            </Grid>
                            <Grid item xs={12} sm={6} md={3}>
                                <Typography
                                    variant="subtitle1"
                                    color="text.secondary"
                                >
                                    Fairness Score (Before)
                                </Typography>
                                <Typography variant="h4" color="#f57c00">
                                    {overview?.fairness_score_before?.score?.toFixed(
                                        1
                                    ) || 'N/A'}
                                    %
                                </Typography>
                            </Grid>
                            <Grid item xs={12} sm={6} md={3}>
                                <Typography
                                    variant="subtitle1"
                                    color="text.secondary"
                                >
                                    Fairness Score (After)
                                </Typography>
                                <Typography
                                    variant="h4"
                                    sx={{
                                        color:
                                            overview?.fairness_score_after
                                                ?.score >= 70
                                                ? '#388e3c'
                                                : '#d32f2f',
                                    }}
                                >
                                    {overview?.fairness_score_after?.score?.toFixed(
                                        1
                                    ) || 'N/A'}
                                    %
                                </Typography>
                            </Grid>
                            <Grid item xs={12} sm={6} md={3}>
                                <Typography
                                    variant="subtitle1"
                                    color="text.secondary"
                                >
                                    Improvement Potential
                                </Typography>
                                <Typography variant="h4" color="#1976d2">
                                    {overview?.fairness_score_before?.improvement_potential?.toFixed(
                                        1
                                    ) || 'N/A'}
                                    %
                                </Typography>
                            </Grid>
                        </Grid>
                    </Paper>
                </Grid>

                {/* LLM Analysis Report */}
                <Grid item xs={12}>
                    <Paper
                        elevation={0}
                        sx={{
                            p: 3,
                            borderRadius: '8px',
                            border: '1px solid #e0e0e0',
                        }}
                    >
                        <Box
                            sx={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                mb: 2,
                            }}
                        >
                            <Typography
                                variant="h5"
                                sx={{ fontWeight: 600, color: '#232f3e' }}
                            >
                                Detailed Analysis Report
                            </Typography>
                            <Button
                                variant="contained"
                                startIcon={<LightbulbIcon />}
                                onClick={handleExplainWithAI}
                                disabled={isLlmLoading}
                                sx={{
                                    textTransform: 'none',
                                    backgroundColor: '#333',
                                    '&:hover': {
                                        backgroundColor: '#555',
                                    },
                                }}
                            >
                                Explain with AI
                            </Button>
                        </Box>
                        <Divider sx={{ mb: 2, borderColor: '#f0f2f2' }} />
                        {renderMarkdown(
                            llmAnalysisReport || '_No analysis available._'
                        )}
                    </Paper>
                </Grid>

                {/* Bias Detection Summary */}
                <Grid item xs={12} md={6}>
                    <Paper
                        elevation={0}
                        sx={{
                            p: 3,
                            borderRadius: '8px',
                            border: '1px solid #e0e0e0',
                        }}
                    >
                        <Typography
                            variant="h5"
                            sx={{ mb: 2, fontWeight: 600, color: '#232f3e' }}
                        >
                            Bias Detection Summary ({selectedAttribute})
                        </Typography>
                        <Divider sx={{ mb: 2, borderColor: '#f0f2f2' }} />
                        {metrics[selectedAttribute]?.bias_detected &&
                        Object.keys(
                            metrics[selectedAttribute]?.bias_detected
                        ).some(
                            (key) =>
                                metrics[selectedAttribute].bias_detected[key]
                                    ?.length > 0
                        ) ? (
                            <Box sx={{ color: '#d32f2f' }}>
                                <Typography
                                    variant="body1"
                                    sx={{ fontWeight: 'bold', mb: 1 }}
                                >
                                    Significant Bias Detected!
                                </Typography>
                                <Typography variant="body2" sx={{ mb: 1 }}>
                                    The model exhibits bias in the{' '}
                                    <strong>{selectedAttribute}</strong>{' '}
                                    feature. Metrics indicating bias:
                                </Typography>
                                <ul style={{ paddingLeft: '20px', margin: 0 }}>
                                    {Object.entries(
                                        metrics[selectedAttribute]
                                            ?.bias_detected || {}
                                    ).flatMap(([metric, values]) =>
                                        values.map((val) => (
                                            <li key={`${metric}-${val}`}>
                                                <Typography variant="body2">
                                                    {metric.replace(/_/g, ' ')}:{' '}
                                                    {val}
                                                </Typography>
                                            </li>
                                        ))
                                    )}
                                </ul>
                            </Box>
                        ) : (
                            <Typography variant="body1" color="#388e3c">
                                No significant biases detected for{' '}
                                <strong>{selectedAttribute}</strong>.
                            </Typography>
                        )}
                    </Paper>
                </Grid>
            </Grid>
        </TabPanel>
    )
}

export default FairnessOverview
