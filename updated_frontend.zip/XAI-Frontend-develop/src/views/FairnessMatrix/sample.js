export const fairnesspayload = {
    overview: {
        fairness_score_before: {
            score: 50.4,
            grade: 'D',
            color: '#FF9800',
            description: 'Bad fairness - substantial bias issues',
            improvement_potential: 49.6,
        },
        fairness_score_after: {
            score: 71.5,
            grade: 'B',
            color: '#8BC34A',
            description: 'Fair fairness - moderate bias detected',
            improvement_potential: 28.5,
        },
        mitigation_strategy_used: 'postprocessing',
    },
    metrics: {
        Gender: {
            fairness_metrics_before: {
                '1_vs_0': {
                    demographic_parity_difference: 0.6210526315789474,
                    equalized_odds_difference: 0.012658227848101266,
                    equal_opportunity_difference: 0.0,
                    disparate_impact_ratio: 4.470588235294118,
                    average_odds_difference: -0.006329113924050633,
                    theil_index: 0.19905793262446422,
                },
            },
            fairness_metrics_after: {
                '1_vs_0': {
                    demographic_parity_difference: -0.010526315789473606,
                    equalized_odds_difference: 0.7721518987341772,
                    equal_opportunity_difference: 0.0,
                    disparate_impact_ratio: 0.9870129870129871,
                    average_odds_difference: -0.3860759493670886,
                    theil_index: 2.1183300813632823e-5,
                },
            },
            group_performance_before: {
                0: {
                    accuracy: 0.9894736842105263,
                    selection_rate: 0.17894736842105263,
                    true_positive_rate: 1.0,
                    false_positive_rate: 0.012658227848101266,
                },
                1: {
                    accuracy: 1.0,
                    selection_rate: 0.8,
                    true_positive_rate: 1.0,
                    false_positive_rate: 0.0,
                },
            },
            group_performance_after: {
                0: {
                    accuracy: 0.35789473684210527,
                    selection_rate: 0.8105263157894737,
                    true_positive_rate: 1.0,
                    false_positive_rate: 0.7721518987341772,
                },
                1: {
                    accuracy: 1.0,
                    selection_rate: 0.8,
                    true_positive_rate: 1.0,
                    false_positive_rate: 0.0,
                },
            },
            bias_detected: {
                demographic_parity_difference: ['1_vs_0'],
                equalized_odds_difference: [],
                equal_opportunity_difference: [],
                disparate_impact_ratio: ['1_vs_0'],
                average_odds_difference: [],
            },
            recommendations: [
                {
                    metric: 'Demographic Parity',
                    issue: 'Disproportionate selection rates across groups.',
                    strategies: [
                        'Reweighing (Pre-processing)',
                        'Exponentiated Gradient (In-processing)',
                        'Grid Search (In-processing)',
                        'Threshold Optimization (Post-processing)',
                    ],
                },
                {
                    metric: 'Disparate Impact',
                    issue: 'Adverse impact on a protected group based on selection rates.',
                    strategies: [
                        'Disparate Impact Remover (Pre-processing)',
                        'Reweighing (Pre-processing)',
                        'Review features for proxies',
                    ],
                },
            ],
        },
    },
    plots: {
        before_mitigation: {
            accuracy_plot: 'image.png',
        },
        after_mitigation: {
            accuracy_plot: 'image.png',
        },
    },
    llm_analysis_report:
        '# Fairness Analysis Report\n\n## 1. Fairness Disparities\n\nThe metrics reveal significant disparities between groups before mitigation:\n\n* **Demographic Parity**: A difference of 0.62 indicates that one group is receiving positive outcomes at a rate 62% higher than the other group.\n* **Disparate Impact Ratio**: At 4.47, this shows that one group is receiving positive outcomes at nearly 4.5 times the rate of the other group - well beyond the 0.8-1.2 range typically considered acceptable.\n* **Theil Index**: The value of 0.20 indicates moderate inequality in the distribution of outcomes.\n\nAfter mitigation:\n* **Demographic Parity Difference**: Improved dramatically to -0.01 (near zero)\n* **Disparate Impact Ratio**: Improved to 0.99, which is very close to the ideal value of 1.0\n* **Equalized Odds Difference**: Worsened significantly from 0.01 to 0.77\n* **Average Odds Difference**: Worsened from -0.006 to -0.39\n\n## 2. Potential Harms\n\nBased on these disparities:\n\n* **Allocation Harms**: Resources, opportunities, or services may be unfairly distributed, with one group receiving favorable outcomes at 4.5 times the rate of another.\n* **Representation Harms**: The model appears to reinforce or amplify existing social biases.\n* **Disadvantaged Groups**: While the specific groups aren\'t named in the data (only labeled as "1" and "0"), group "0" appears to be disadvantaged in the original model.\n* **Post-Mitigation Concerns**: While demographic parity improved, the equalized odds difference worsened substantially, suggesting the mitigation created new fairness problems while solving others.\n\n## 3. Compliance & Ethical Implications\n\n* **Before Mitigation**:\n  * Clear violation of demographic parity principles\n  * The disparate impact ratio of 4.47 would likely fail the "80% rule" used in US employment law\n  * Equal opportunity difference of 0 suggests similar true positive rates across groups\n\n* **After Mitigation**:\n  * Demographic parity and disparate impact issues were resolved\n  * New violations of equalized odds emerged (0.77 difference)\n  * This "fairness gerrymandering" (fixing one fairness metric while breaking another) could create new legal vulnerabilities\n\n* **Legal Risk**: The initial disparities could trigger regulatory scrutiny under anti-discrimination laws in domains like lending, housing, employment, or education.\n\n## 4. Suggested Mitigations\n\nThe current mitigation strategy appears to be a **post-processing** approach that successfully addressed demographic parity but created new issues with equalized odds.\n\nRecommended strategies:\n\n* **In-processing Methods**: \n  * Implement fairness constraints during model training\n  * Use adversarial debiasing techniques to reduce correlation between predictions and sensitive attributes\n  * Apply constraint-based optimization that balances multiple fairness metrics simultaneously\n\n* **Pre-processing Methods**:\n  * Reweighting training examples to balance representation\n  * Generate synthetic data to address imbalances\n  * Transform features to reduce correlation with protected attributes\n\n* **Balanced Approach**: \n  * The most appropriate next step would be an in-processing approach that can optimize for multiple fairness constraints simultaneously, rather than fixing one metric at the expense of others.\n\n## 5. Communication to Stakeholders\n\n**For Business Leaders**:\n\nOur fairness audit revealed significant disparities in how our model treats different demographic groups. Initially, one group was receiving favorable outcomes at 4.5 times the rate of another group - a level that poses substantial business and legal risks.\n\nOur first mitigation attempt improved overall fairness from a "D" grade (50.4) to a "B" grade (71.5), but it created new fairness issues while solving others. This is like fixing a leak in one part of a pipe while creating a new leak elsewhere.\n\nWe recommend implementing fairness constraints directly in our model training process to achieve a more balanced solution that addresses multiple fairness concerns simultaneously. This approach will:\n- Reduce legal and reputational risks\n- Ensure more equitable outcomes across groups\n- Provide a more defensible position if our practices are questioned\n\nWithout further improvements, we remain exposed to potential discrimination claims, negative publicity, and erosion of trust among customers from disadvantaged groups.',
}
