import { configureStore } from '@reduxjs/toolkit'
import counterReducer from './counterSlice'
import authReducer from './authSlice'
import uploadReducer from './uploadSlice'
import llmReducer from './llmSlice'
import driftReportReducer from './driftReportSlice'
import driftConfigReducer from './driftConfigSlice'
import fairnessReducer from './fairnessSlice'
import regressionReducer from './regressionSlice'
import classificationReducer from './classificationSlice'

export const store = configureStore({
    reducer: {
        counter: counterReducer,
        auth: authReducer,
        upload: uploadReducer,
        llm: llmReducer,
        driftReport: driftReportReducer,
        driftConfig: driftConfigReducer,
        fairness: fairnessReducer,
        regression: regressionReducer,
        classification: classificationReducer,
    },
})
