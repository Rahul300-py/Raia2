import { createSlice } from '@reduxjs/toolkit'

const initialState = {
    excludedColumns: [],
    useDateColumnSplit: false,
    selectedDateColumn: '',
    referenceStartDate: null,
    currentStartDate: null,
    projectList: [],
}

const driftConfigSlice = createSlice({
    name: 'driftConfig',
    initialState,
    reducers: {
        setExcludedColumns: (state, action) => {
            state.excludedColumns = action.payload
        },
        setUseDateColumnSplit: (state, action) => {
            state.useDateColumnSplit = action.payload
        },
        setSelectedDateColumn: (state, action) => {
            state.selectedDateColumn = action.payload
        },
        setReferenceStartDate: (state, action) => {
            state.referenceStartDate = action.payload
        },
        setCurrentStartDate: (state, action) => {
            state.currentStartDate = action.payload
        },
        resetConfig: (state) => {
            Object.assign(state, initialState)
        },
        setProjectList: (state, action) => {
            state.projectList = action.payload
        },
    },
})

export const {
    setExcludedColumns,
    setUseDateColumnSplit,
    setSelectedDateColumn,
    setReferenceStartDate,
    setCurrentStartDate,
    resetConfig,
    setProjectList,
} = driftConfigSlice.actions

export default driftConfigSlice.reducer
export const selectDriftConfig = (state) => state.driftConfig
