// components/SelectFeaturesStep.jsx
import React from 'react'
import {
    Box,
    Typography,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    Checkbox,
    ListItemText,
    OutlinedInput,
    TextField,
} from '@mui/material'

const columns = ['Age', 'Gender', 'Income', 'Subscription']

function SelectFeaturesStep() {
    return (
        <Box>
            <Typography variant="h6" gutterBottom>
                Select Features & Target
            </Typography>

            <FormControl fullWidth margin="normal">
                <InputLabel id="target-label">Target Column</InputLabel>
                <Select
                    labelId="target-label"
                    defaultValue="Subscription"
                    input={<OutlinedInput label="Target Column" />}
                >
                    {columns.map((col) => (
                        <MenuItem key={col} value={col}>
                            {col}
                        </MenuItem>
                    ))}
                </Select>
            </FormControl>

            <FormControl fullWidth margin="normal">
                <InputLabel id="features-label">Input Features</InputLabel>
                <Select
                    labelId="features-label"
                    multiple
                    defaultValue={['Age', 'Income']}
                    input={<OutlinedInput label="Input Features" />}
                    renderValue={(selected) => selected.join(', ')}
                >
                    {columns.map((col) => (
                        <MenuItem key={col} value={col}>
                            <Checkbox
                                checked={['Age', 'Income'].includes(col)}
                            />
                            <ListItemText primary={col} />
                        </MenuItem>
                    ))}
                </Select>
            </FormControl>

            <FormControl fullWidth margin="normal">
                <InputLabel id="model-label">Select Model</InputLabel>
                <Select labelId="model-label" defaultValue="Random Forest">
                    <MenuItem value="Random Forest">Random Forest</MenuItem>
                    <MenuItem value="Logistic Regression">
                        Logistic Regression
                    </MenuItem>
                    <MenuItem value="Gradient Boosting">
                        Gradient Boosting
                    </MenuItem>
                    <MenuItem value="Neural Network">Neural Network</MenuItem>
                </Select>
            </FormControl>
        </Box>
    )
}

export default SelectFeaturesStep
