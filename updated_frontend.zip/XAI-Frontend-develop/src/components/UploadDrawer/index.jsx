/* eslint-disable no-unused-vars */
import { Box, Drawer, List, ListItem, IconButton } from '@mui/material'
import { ChevronLeft, Menu as MenuIcon } from '@mui/icons-material'
import { useSelector, useDispatch } from 'react-redux'
import { fetchDriftReport } from '../../store/driftReportSlice'

import {
    fetchDataPreview,
    fetchDatasets,
    fetchMitigationStrategies,
} from '../../store/fairnessSlice'
import {
    setExcludedColumns,
    setUseDateColumnSplit,
    setSelectedDateColumn,
    setReferenceStartDate,
    setCurrentStartDate,
} from '../../store/driftConfigSlice'
import { useEffect, useState } from 'react'

import DataDriftDrawer from './DataDriftDrawer'
import FairnessDrawer from './FairnessDrawer'
import RegressionDrawer from './RegressionDrawer'
import ClassificationDrawer from './ClassificationDrawer'
const UploadDrawer = ({
    open,
    setOpen,
    fileState,
    fairnessfileState,
    handleBrowse,
    handleBrowseFairness,
    handleSavefairnessData,
    handleSaveRegressionData,
    handleSave,
    loading,
    percentage,
    setPercentage,
    logoSrc,
    drawerWidthOpen = 350,
    drawerWidthClosed = 72,
    navigate,
    setActiveTab,
    fetchRecord,
    activeTab,
    selectedSensitiveFeature,
    setSelectedSensitiveFeature,
    setSelectedTargetColumn,
    selectedTargetColumn,
    runFairnessAnalysis,
    runRegressionAnalysis,
    runRegressionModelExplainibility,
    selectedMitigationStrategy,
    setSlectedMitigationStrategy,
    handleSaveClassificationData,
    runClassificationReport,
    runClassificationAnalysis,
    runClassificationDashboard,
    modelFormat,
    setModelFormat,
}) => {
    const handleToggle = () => setOpen(!open)

    // New state variables for the column and date selectors
    const dispatch = useDispatch()
    const availableColumns = useSelector(
        (state) => state.driftReport.availableColumns
    )
    const availableColumnsLoading = useSelector(
        (state) => state.driftReport.loading
    )
    const { mitigationStrategies, datasets, dataPreview } = useSelector(
        (state) => state.fairness
    )
    const regressionData = useSelector((state) => state.regression)
    const regressionDatasets = regressionData?.datasets
    const regressionDataPreview = regressionData?.dataPreview
    // const fairnessState = useSelector((state) => state.fairness)
    // const loading1 = useSelector((state) => state.driftReport.loading)
    // const error = useSelector((state) => state.driftReport.error)
    const driftConfig = useSelector((state) => state.driftConfig)
    const {
        excludedColumns,
        useDateColumnSplit,
        selectedDateColumn,
        referenceStartDate,
        currentStartDate,
    } = driftConfig

    const [showUploadForm1, setShowUploadForm1] = useState(false)
    const [showUploadForm2, setShowUploadForm2] = useState(false)
    //const [modelFormat, setModelFormat] = useState('onnx')

    useEffect(() => {
        dispatch(fetchDriftReport())
        dispatch(fetchMitigationStrategies())
        dispatch(fetchDatasets())
        // dispatch(fetchMitigationStrategies(localStorage.getItem('token')))
    }, [dispatch])

    const handleFetchDetails = async () => {
        fetchRecord(true)
    }

    useEffect(() => {
        if (datasets) {
            dispatch(fetchDataPreview())
        }
    }, [datasets])

    useEffect(() => {
        if (datasets) {
            dispatch(fetchDataPreview())
        }
    }, [])

    return (
        <Drawer
            variant="permanent"
            sx={{
                width: open ? drawerWidthOpen : drawerWidthClosed,
                flexShrink: 0,
                whiteSpace: 'nowrap',
                [`& .MuiDrawer-paper`]: {
                    width: open ? drawerWidthOpen : drawerWidthClosed,
                    transition: 'width 0.3s',
                    overflowX: 'hidden',
                    bgcolor: 'primary.dark',
                    color: 'text.primary',
                    boxSizing: 'border-box',
                },
            }}
        >
            <List sx={{ paddingBottom: 20 }}>
                {/* Header */}
                <ListItem
                    disablePadding
                    sx={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: open ? 'space-between' : 'center',
                        p: 1.5,
                    }}
                >
                    {open && (
                        <Box
                            sx={{ cursor: 'pointer' }}
                            onClick={() => navigate('/home')}
                        >
                            <img
                                src={logoSrc}
                                alt="Logo"
                                style={{ width: '100px' }}
                            />
                        </Box>
                    )}
                    <IconButton
                        onClick={handleToggle}
                        sx={{ color: '#fff', padding: 0 }}
                    >
                        {open ? <ChevronLeft /> : <MenuIcon />}
                    </IconButton>
                </ListItem>

                {/* Upload Section */}
                {activeTab === 1 ? (
                    <DataDriftDrawer
                        open={open}
                        setOpen={setOpen}
                        showUploadForm1={showUploadForm1}
                        setShowUploadForm1={setShowUploadForm1}
                        handleBrowse={handleBrowse}
                        fileState={fileState}
                        handleSave={handleSave}
                        loading={loading}
                        showUploadForm2={showUploadForm2}
                        setShowUploadForm2={setShowUploadForm2}
                        percentage={percentage}
                        setPercentage={setPercentage}
                        availableColumnsLoading={availableColumnsLoading}
                        excludedColumns={excludedColumns}
                        setExcludedColumns={setExcludedColumns}
                        availableColumns={availableColumns}
                        useDateColumnSplit={useDateColumnSplit}
                        setUseDateColumnSplit={setUseDateColumnSplit}
                        selectedDateColumn={selectedDateColumn}
                        setSelectedDateColumn={setSelectedDateColumn}
                        referenceStartDate={referenceStartDate}
                        setReferenceStartDate={setReferenceStartDate}
                        currentStartDate={currentStartDate}
                        setCurrentStartDate={setCurrentStartDate}
                        handleFetchDetails={handleFetchDetails}
                    />
                ) : activeTab === 2 ? (
                    <FairnessDrawer
                        open={open}
                        setOpen={setOpen}
                        loading={loading}
                        handleBrowseFairness={handleBrowseFairness}
                        fairnessfileState={fairnessfileState}
                        modelFormat={modelFormat}
                        setModelFormat={setModelFormat}
                        handleSavefairnessData={handleSavefairnessData}
                        selectedTargetColumn={selectedTargetColumn}
                        setSelectedTargetColumn={setSelectedTargetColumn}
                        dataPreview={dataPreview}
                        setSelectedSensitiveFeature={
                            setSelectedSensitiveFeature
                        }
                        selectedSensitiveFeature={selectedSensitiveFeature}
                        selectedMitigationStrategy={selectedMitigationStrategy}
                        setSlectedMitigationStrategy={
                            setSlectedMitigationStrategy
                        }
                        mitigationStrategies={mitigationStrategies}
                        runFairnessAnalysis={runFairnessAnalysis}
                    />
                ) : activeTab === 3 ? (
                    <RegressionDrawer
                        open={open}
                        setOpen={setOpen}
                        loading={loading}
                        handleBrowseFairness={handleBrowseFairness}
                        fairnessfileState={fairnessfileState}
                        modelFormat={modelFormat}
                        setModelFormat={setModelFormat}
                        selectedTargetColumn={selectedTargetColumn}
                        setSelectedTargetColumn={setSelectedTargetColumn}
                        handleSaveRegressionData={handleSaveRegressionData}
                        regressionDataPreview={regressionDataPreview}
                        runRegressionAnalysis={runRegressionAnalysis}
                        runRegressionModelExplainibility={
                            runRegressionModelExplainibility
                        }
                    />
                ) : activeTab === 4 ? (
                    <ClassificationDrawer
                        open={open}
                        setOpen={setOpen}
                        loading={loading}
                        handleBrowseFairness={handleBrowseFairness}
                        fairnessfileState={fairnessfileState}
                        modelFormat={modelFormat}
                        setModelFormat={setModelFormat}
                        selectedTargetColumn={selectedTargetColumn}
                        setSelectedTargetColumn={setSelectedTargetColumn}
                        handleSaveClassificationData={
                            handleSaveClassificationData
                        }
                        runClassificationReport={runClassificationReport}
                        runClassificationAnalysis={runClassificationAnalysis}
                        runClassificationDashboard={runClassificationDashboard}
                    />
                ) : null}
            </List>
        </Drawer>
    )
}

export default UploadDrawer
