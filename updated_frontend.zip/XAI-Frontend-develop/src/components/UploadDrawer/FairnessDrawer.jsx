import React from 'react'
import {
    ListItem,
    Typography,
    Card,
    CardContent,
    Stack,
    Button,
} from '@mui/material'
import AssessmentIcon from '@mui/icons-material/Assessment'
import ModelUploadSection from '../common/ModelUploadSection'
import ColumnSelector from '../common/ColumnSelector'
import DrawerIconList from '../common/DrawerIconList'

function FairnessDrawer({
    open,
    setOpen,
    loading,
    handleBrowseFairness,
    fairnessfileState,
    modelFormat,
    setModelFormat,
    handleSavefairnessData,
    selectedTargetColumn,
    setSelectedTargetColumn,
    dataPreview,
    setSelectedSensitiveFeature,
    selectedSensitiveFeature,
    selectedMitigationStrategy,
    setSlectedMitigationStrategy,
    mitigationStrategies,
    runFairnessAnalysis,
}) {
    return open ? (
        <ListItem disablePadding sx={{ display: 'block', px: 2.5, mt: 3 }}>
            <Typography
                variant="subtitle"
                sx={{ color: '#fff', fontWeight: 'bold' }}
            >
                Fairness Analysis
            </Typography>
            <Card sx={{ my: 2, borderRadius: '8px' }}>
                <CardContent sx={{ p: 2 }}>
                    <ModelUploadSection
                        fileState={fairnessfileState}
                        handleBrowse={handleBrowseFairness}
                        modelFormat={modelFormat}
                        setModelFormat={setModelFormat}
                        handleSaveData={handleSavefairnessData}
                    />
                </CardContent>
            </Card>
            <Card sx={{ my: 2, borderRadius: '8px' }}>
                <CardContent sx={{ p: 2 }}>
                    <Stack spacing={3} my={2}>
                        <ColumnSelector
                            label="Target Column"
                            value={selectedTargetColumn}
                            onChange={(e) =>
                                setSelectedTargetColumn(e.target.value)
                            }
                            options={dataPreview?.columns}
                            loading={loading}
                            placeholder="Select Target Column"
                        />
                        <ColumnSelector
                            label="Sensitive Feature"
                            value={selectedSensitiveFeature}
                            onChange={(e) =>
                                setSelectedSensitiveFeature(e.target.value)
                            }
                            options={dataPreview?.columns}
                            loading={loading}
                            placeholder="Select Sensitive Feature"
                        />
                        <ColumnSelector
                            label="Mitigation Strategy"
                            value={selectedMitigationStrategy}
                            onChange={(e) =>
                                setSlectedMitigationStrategy(e.target.value)
                            }
                            options={mitigationStrategies}
                            loading={loading}
                            placeholder="Select Mitigation Strategy"
                            optionValueKey="value"
                            optionLabelKey="label"
                        />
                        <Button
                            variant="contained"
                            startIcon={<AssessmentIcon />}
                            onClick={runFairnessAnalysis}
                            sx={{
                                width: '100%',
                                padding: 1,
                                backgroundColor: '#232f3e',
                                '&:hover': { backgroundColor: '#3a475b' },
                            }}
                        >
                            Run Analysis
                        </Button>
                    </Stack>
                </CardContent>
            </Card>
        </ListItem>
    ) : (
        <DrawerIconList onIconClick={() => setOpen(true)} />
    )
}

export default FairnessDrawer
