// src/components/Footer.js
import React from 'react'
import {
    Box,
    Typography,
    Container,
    Grid,
    Stack,
    Link,
    TextField,
    Button,
} from '@mui/material'
import GitHubIcon from '@mui/icons-material/GitHub'
import XIcon from '@mui/icons-material/Twitter' // Using XIcon for Twitter, adjust if needed
import LinkedInIcon from '@mui/icons-material/LinkedIn'
import YouTubeIcon from '@mui/icons-material/YouTube'

// Assuming your logo is in public folder or imported from assets
const logoSrc = '/logo-nav.png'

const NewFooter = () => {
    return (
        <Box
            sx={{
                width: '100%',
                backgroundColor: '#0d0d2b',
                color: '#fff',
                py: { xs: 8, md: 12 },
            }}
        >
            {/* "No credit card required" banner */}
            <Box
                sx={{
                    backgroundColor: 'rgb(48 53 83)', // Slightly lighter purple
                    textAlign: 'center',
                    py: 2,
                    mb: 8,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: 1,
                }}
            >
                <Typography
                    variant="body1"
                    sx={{ color: 'primary.light', fontWeight: 'bold' }}
                >
                    &#10003; No credit card required
                </Typography>
            </Box>

            <Container maxWidth="lg">
                <Grid container spacing={5}>
                    {/* Company Info */}
                    <Grid item xs={12} md={4}>
                        <img
                            src={logoSrc}
                            alt="RAIA Logo"
                            style={{
                                width: '150px',
                                filter: 'brightness(0) invert(1)',
                                marginBottom: '15px',
                            }}
                        />
                        <Typography
                            variant="body2"
                            sx={{ color: 'primary.light', mb: 3 }}
                        >
                            Evaluate, test and monitor your AI-powered products.
                        </Typography>
                    </Grid>

                    {/* Navigation Links */}
                    <Grid item xs={12} md={6}>
                        <Grid container spacing={{ xs: 2, sm: 4 }}>
                            <Grid item xs={6} sm={4}>
                                <Stack spacing={1}>
                                    <Typography
                                        variant="subtitle1"
                                        sx={{ fontWeight: 'bold', mb: 1 }}
                                    >
                                        LLM testing platform
                                    </Typography>
                                    <Link
                                        href="#"
                                        color="inherit"
                                        sx={{ fontSize: '0.9em' }}
                                    >
                                        AI risk assessment
                                    </Link>
                                    <Link
                                        href="#"
                                        color="inherit"
                                        sx={{ fontSize: '0.9em' }}
                                    >
                                        RAG testing
                                    </Link>
                                    <Link
                                        href="#"
                                        color="inherit"
                                        sx={{ fontSize: '0.9em' }}
                                    >
                                        Adversarial testing
                                    </Link>
                                    <Link
                                        href="#"
                                        color="inherit"
                                        sx={{ fontSize: '0.9em' }}
                                    >
                                        AI Agent testing
                                    </Link>
                                    <Link
                                        href="#"
                                        color="inherit"
                                        sx={{ fontSize: '0.9em' }}
                                    >
                                        ML monitoring
                                    </Link>
                                    <Link
                                        href="#"
                                        color="inherit"
                                        sx={{ fontSize: '0.9em' }}
                                    >
                                        Open-source
                                    </Link>
                                </Stack>
                            </Grid>
                            <Grid item xs={6} sm={4}>
                                <Stack spacing={1}>
                                    <Typography
                                        variant="subtitle1"
                                        sx={{ fontWeight: 'bold', mb: 1 }}
                                    >
                                        Blog
                                    </Typography>
                                    <Link
                                        href="#"
                                        color="inherit"
                                        sx={{ fontSize: '0.9em' }}
                                    >
                                        Tutorials
                                    </Link>
                                    <Link
                                        href="#"
                                        color="inherit"
                                        sx={{ fontSize: '0.9em' }}
                                    >
                                        Guides
                                    </Link>
                                    <Link
                                        href="#"
                                        color="inherit"
                                        sx={{ fontSize: '0.9em' }}
                                    >
                                        ML platforms
                                    </Link>
                                    <Link
                                        href="#"
                                        color="inherit"
                                        sx={{ fontSize: '0.9em' }}
                                    >
                                        ML use cases
                                    </Link>
                                    <Link
                                        href="#"
                                        color="inherit"
                                        sx={{ fontSize: '0.9em' }}
                                    >
                                        LLM evaluations course
                                    </Link>
                                </Stack>
                            </Grid>
                            <Grid item xs={6} sm={4}>
                                <Stack spacing={1}>
                                    <Typography
                                        variant="subtitle1"
                                        sx={{ fontWeight: 'bold', mb: 1 }}
                                    >
                                        Pricing
                                    </Typography>
                                    <Link
                                        href="#"
                                        color="inherit"
                                        sx={{ fontSize: '0.9em' }}
                                    >
                                        Docs
                                    </Link>
                                    <Link
                                        href="#"
                                        color="inherit"
                                        sx={{ fontSize: '0.9em' }}
                                    >
                                        GitHub
                                    </Link>
                                    <Link
                                        href="#"
                                        color="inherit"
                                        sx={{ fontSize: '0.9em' }}
                                    >
                                        Community
                                    </Link>
                                    <Link
                                        href="#"
                                        color="inherit"
                                        sx={{ fontSize: '0.9em' }}
                                    >
                                        Privacy policy
                                    </Link>
                                    <Link
                                        href="#"
                                        color="inherit"
                                        sx={{ fontSize: '0.9em' }}
                                    >
                                        Terms of service
                                    </Link>
                                </Stack>
                            </Grid>
                        </Grid>
                    </Grid>

                    {/* Newsletter */}
                    <Grid item xs={12} md={2}>
                        <Typography
                            variant="subtitle1"
                            sx={{ fontWeight: 'bold', mb: 2 }}
                        >
                            Subscribe to our monthly newsletter
                        </Typography>
                        <Stack direction="row" spacing={1}>
                            <TextField
                                variant="outlined"
                                placeholder="Enter your email"
                                size="small"
                                sx={{
                                    flexGrow: 1,
                                    '& .MuiOutlinedInput-root': {
                                        borderRadius: '5px',
                                        backgroundColor: 'rgb(48 53 83)', // Darker input background
                                        color: '#fff',
                                        '& fieldset': {
                                            borderColor: 'transparent',
                                        },
                                        '&:hover fieldset': {
                                            borderColor: 'transparent',
                                        },
                                        '&.Mui-focused fieldset': {
                                            borderColor: 'primary.main',
                                        },
                                    },
                                    '& .MuiInputBase-input::placeholder': {
                                        color: 'rgba(255, 255, 255, 0.7)',
                                        opacity: 1,
                                    },
                                }}
                            />
                            <Button
                                variant="contained"
                                sx={{
                                    backgroundColor: '#fff',
                                    color: '#2d0047',
                                    fontWeight: 'bold',
                                    '&:hover': { backgroundColor: 'grey.200' },
                                }}
                            >
                                Subscribe
                            </Button>
                        </Stack>
                    </Grid>
                </Grid>

                {/* Copyright and Social Icons */}
                <Stack
                    direction={{ xs: 'column', sm: 'row' }}
                    justifyContent="space-between"
                    alignItems="center"
                    sx={{
                        mt: { xs: 5, md: 8 },
                        pt: { xs: 3, md: 5 },
                        borderTop: '1px solid rgb(48 53 83)',
                    }}
                >
                    <Typography
                        variant="body2"
                        sx={{ color: 'primary.light', mb: { xs: 2, sm: 0 } }}
                    >
                        © 2025. RAIA. All rights reserved
                    </Typography>
                    <Stack direction="row" spacing={2}>
                        <Link href="#" color="inherit">
                            <GitHubIcon />
                        </Link>
                        <Link href="#" color="inherit">
                            <XIcon />
                        </Link>
                        <Link href="#" color="inherit">
                            <LinkedInIcon />
                        </Link>
                        <Link href="#" color="inherit">
                            <YouTubeIcon />
                        </Link>
                    </Stack>
                </Stack>
            </Container>
        </Box>
    )
}

export default NewFooter
