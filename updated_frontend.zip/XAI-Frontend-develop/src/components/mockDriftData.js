// src/mockDriftData.js

export const mockDriftData = {
    overallDriftScore: 0.32, // Example: High overall drift

    targetDrift: {
        trainSurvivedPct: 0.38, // Original survival rate (example)
        liveSurvivedPct: 0.25, // Simulated lower survival rate in new data
        psi: 0.2, // Moderate drift for target
        status: 'Moderate',
    },

    featureDriftScores: [
        { feature: 'Age', psi: 0.28, status: 'High' }, // High drift simulated
        { feature: 'Fare', psi: 0.15, status: 'Moderate' }, // Moderate drift
        { feature: 'Pclass', psi: 0.08, status: 'Low' }, // Low drift
        { feature: 'Sex', psi: 0.02, status: 'Stable' }, // Stable
        { feature: 'Embarked', psi: 0.35, status: 'High' }, // High drift due to missing values or new patterns
        { feature: 'SibSp', psi: 0.09, status: 'Low' },
        { feature: 'Parch', psi: 0.07, status: 'Low' },
    ],

    featureDistributions: {
        Age: [
            { bin: '0-10', trainPct: 0.05, livePct: 0.06 },
            { bin: '10-20', trainPct: 0.15, livePct: 0.13 },
            { bin: '20-30', trainPct: 0.3, livePct: 0.28 },
            { bin: '30-40', trainPct: 0.25, livePct: 0.2 }, // Simulating fewer 30-40 year olds
            { bin: '40-50', trainPct: 0.15, livePct: 0.18 },
            { bin: '50+', trainPct: 0.1, livePct: 0.15 }, // Simulating more older passengers
        ],
        Fare: [
            { bin: '0-20', trainPct: 0.5, livePct: 0.4 }, // Simulating fewer low fares
            { bin: '20-40', trainPct: 0.25, livePct: 0.3 },
            { bin: '40-60', trainPct: 0.15, livePct: 0.2 }, // Simulating more mid-range fares
            { bin: '60+', trainPct: 0.1, livePct: 0.1 },
        ],
        Pclass: [
            { category: '1st', trainPct: 0.22, livePct: 0.28 }, // Simulating more 1st class
            { category: '2nd', trainPct: 0.2, livePct: 0.18 },
            { category: '3rd', trainPct: 0.45, livePct: 0.39 },
        ],
        Sex: [
            { category: 'male', trainPct: 0.65, livePct: 0.55 }, // Simulating fewer males
            { category: 'female', trainPct: 0.35, livePct: 0.45 }, // Simulating more females
        ],
        Embarked: [
            { category: 'S', trainPct: 0.72, livePct: 0.6 },
            { category: 'C', trainPct: 0.19, livePct: 0.25 }, // More from Cherbourg
            { category: 'Q', trainPct: 0.09, livePct: 0.15 }, // More from Queenstown
        ],
        SibSp: [
            { category: '0', trainPct: 0.68, livePct: 0.7 },
            { category: '1', trainPct: 0.23, livePct: 0.2 },
            { category: '2+', trainPct: 0.09, livePct: 0.1 },
        ],
        Parch: [
            { category: '0', trainPct: 0.76, livePct: 0.75 },
            { category: '1', trainPct: 0.14, livePct: 0.15 },
            { category: '2+', trainPct: 0.1, livePct: 0.1 },
        ],
    },

    timeSeriesDrift: [
        {
            date: '2023-01-01',
            overallPsi: 0.05,
            Age: 0.03,
            Fare: 0.06,
            Pclass: 0.02,
            Sex: 0.01,
            Embarked: 0.04,
            SibSp: 0.01,
            Parch: 0.01,
        },
        {
            date: '2023-01-08',
            overallPsi: 0.08,
            Age: 0.05,
            Fare: 0.09,
            Pclass: 0.03,
            Sex: 0.02,
            Embarked: 0.07,
            SibSp: 0.02,
            Parch: 0.02,
        },
        {
            date: '2023-01-15',
            overallPsi: 0.15,
            Age: 0.12,
            Fare: 0.18,
            Pclass: 0.05,
            Sex: 0.02,
            Embarked: 0.15,
            SibSp: 0.03,
            Parch: 0.03,
        },
        {
            date: '2023-01-22',
            overallPsi: 0.25,
            Age: 0.2,
            Fare: 0.3,
            Pclass: 0.08,
            Sex: 0.02,
            Embarked: 0.25,
            SibSp: 0.04,
            Parch: 0.04,
        },
        {
            date: '2023-01-29',
            overallPsi: 0.32,
            Age: 0.28,
            Fare: 0.15,
            Pclass: 0.08,
            Sex: 0.02,
            Embarked: 0.35,
            SibSp: 0.05,
            Parch: 0.05,
        },
    ],
}
