// components/ConfigureDataStep.jsx
import React from 'react'
import {
    Box,
    Typography,
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableRow,
    FormControl,
    Select,
    MenuItem,
    IconButton,
    Checkbox,
} from '@mui/material'
import DeleteIcon from '@mui/icons-material/Delete'

const sampleColumns = [
    { name: 'Age', type: 'number', missing: false },
    { name: 'Gender', type: 'categorical', missing: false },
    { name: 'Income', type: 'number', missing: true },
]

function ConfigureDataStep() {
    return (
        <Box>
            <Typography variant="h6" gutterBottom>
                Preview & Configure Dataset
            </Typography>
            <Table size="small">
                <TableHead>
                    <TableRow>
                        <TableCell>Include</TableCell>
                        <TableCell>Column</TableCell>
                        <TableCell>Type</TableCell>
                        <TableCell>Missing Values</TableCell>
                        <TableCell>Action</TableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {sampleColumns.map((col, idx) => (
                        <TableRow key={idx}>
                            <TableCell>
                                <Checkbox defaultChecked />
                            </TableCell>
                            <TableCell>{col.name}</TableCell>
                            <TableCell>
                                <FormControl fullWidth size="small">
                                    <Select defaultValue={col.type}>
                                        <MenuItem value="number">
                                            Numerical
                                        </MenuItem>
                                        <MenuItem value="categorical">
                                            Categorical
                                        </MenuItem>
                                        <MenuItem value="text">Text</MenuItem>
                                        <MenuItem value="date">Date</MenuItem>
                                    </Select>
                                </FormControl>
                            </TableCell>
                            <TableCell>{col.missing ? 'Yes' : 'No'}</TableCell>
                            <TableCell>
                                <IconButton color="error">
                                    <DeleteIcon />
                                </IconButton>
                            </TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </Box>
    )
}

export default ConfigureDataStep
