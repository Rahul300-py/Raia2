import React from 'react'
import {
    Box,
    Typography,
    Paper,
    Grid,
    Container,
    List,
    ListItem,
    ListItemIcon,
    ListItemText,
} from '@mui/material'
import CheckCircleIcon from '@mui/icons-material/CheckCircle'

const explainabilityFeatures = [
    {
        icon: '📈',
        title: 'SHAP Analysis',
        subtitle:
            'Shapley Additive Explanations for global and local interpretability',
        points: [
            'Feature importance rankings',
            'Individual prediction breakdowns',
            'Interactive dependency plots',
            'Force plots and waterfall charts',
        ],
    },
    {
        icon: '🎯',
        title: 'LIME Explanations',
        subtitle:
            'Local Interpretable Model-agnostic Explanations for any model type',
        points: [
            'Tabular, text, and image explanations',
            'Perturbation-based analysis',
            'Local surrogate models',
            'Confidence intervals',
        ],
    },
    {
        icon: '🧪',
        title: 'What-if Analysis',
        subtitle:
            'Interactive exploration of model behavior under different scenarios',
        points: [
            'Counterfactual generation',
            'Sensitivity analysis',
            'Decision boundary visualization',
            'Multi-dimensional exploration',
        ],
    },
]

const ExplainabilitySuiteSection = () => {
    return (
        <Box
            sx={{
                color: '#fff',
                py: 8,
            }}
        >
            <Container maxWidth="lg">
                <Typography
                    variant="h4"
                    sx={{
                        color: 'primary.dark',
                        fontWeight: 700,
                        mb: 2,
                        textAlign: 'center',
                    }}
                >
                    Advanced Explainability Suite{' '}
                </Typography>
                <Typography
                    variant="subtitle1"
                    sx={{
                        color: 'rgba(0, 0, 0, 0.7)',
                        mb: 5,
                        textAlign: 'center',
                        maxWidth: '600px',
                        mx: 'auto',
                    }}
                >
                    Understand every prediction with state-of-the-art
                    interpretability methods.
                </Typography>

                <Grid container spacing={4}>
                    {explainabilityFeatures.map((feature, index) => (
                        <Grid item xs={12} sm={6} md={4} key={index}>
                            <Paper
                                elevation={0}
                                sx={{
                                    // backgroundColor: '#111827',
                                    border: '1px solid rgb(158, 180, 211)',
                                    borderRadius: '16px',
                                    p: 4,
                                    height: '100%',
                                    maxWidth: '350px',
                                    cursor: 'pointer',
                                    transition: 'all 0.3s ease',
                                    '&:hover': {
                                        boxShadow:
                                            '0 6px 20px rgba(0,0,0,0.08)',
                                        transform: 'translateY(-3px)',
                                    },
                                }}
                            >
                                {/* <Box
                                    sx={{
                                        background:
                                            'linear-gradient(135deg, #6366F1 0%, #8B5CF6 100%)',
                                        borderRadius: '12px',
                                        width: 50,
                                        height: 50,
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        fontSize: '26px',
                                        mb: 2,
                                    }}
                                >
                                    {feature.icon}
                                </Box> */}
                                <Typography
                                    variant="h6"
                                    sx={{
                                        fontWeight: 700,

                                        mb: 1,
                                    }}
                                >
                                    {feature.icon} {feature.title}
                                </Typography>
                                <Typography
                                    variant="body2"
                                    sx={{
                                        mb: 2,
                                    }}
                                >
                                    {feature.subtitle}
                                </Typography>

                                <List dense>
                                    {feature.points.map((point, i) => (
                                        <ListItem key={i} disableGutters>
                                            <ListItemIcon
                                                sx={{
                                                    minWidth: '30px',
                                                    color: 'rgb(186, 195, 255)',
                                                }}
                                            >
                                                <CheckCircleIcon fontSize="small" />
                                            </ListItemIcon>
                                            <ListItemText primary={point} />
                                        </ListItem>
                                    ))}
                                </List>
                            </Paper>
                        </Grid>
                    ))}
                </Grid>
            </Container>
        </Box>
    )
}

export default ExplainabilitySuiteSection
