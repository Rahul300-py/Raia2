// src/components/HeroSection.js
import React from 'react'
import { Box, Typography, Button, Container } from '@mui/material'

const HeroSection = () => {
    return (
        <Box
            sx={{
                textAlign: 'center',
                py: { xs: 10, md: 15 },
                px: 2,
                maxWidth: { xs: '100%' },
                width: '100%',
                mx: 'auto',
                position: 'relative',
                zIndex: 1,
                backgroundPosition: 'center top',
                borderRadius: '15px', // Still useful for the implied shape
                mt: 5,
                mb: { xs: -5, md: -10 }, // Negative margin to overlap with the next section
            }}
        >
            <Typography
                variant="h2"
                component="h2"
                sx={{ fontWeight: '550', mb: 3, lineHeight: 1.2 }}
            >
                Next-Generation{' '}
                <Box component="span" sx={{ color: 'secondary.main' }}>
                    AI Explainability{' '}
                </Box>{' '}
                & <br />
                <Box component="span" sx={{ color: 'secondary.main' }}>
                    Monitoring
                </Box>{' '}
                Platform
            </Typography>
            <Typography
                variant="body1"
                sx={{ color: 'text.secondary', mb: 5, lineHeight: 1.6 }}
            >
                Unlock the black box of AI with advanced interpretability tools,
                real-time monitoring, and comprehensive bias detection.
            </Typography>
            <Button
                variant="contained"
                color="primary"
                size="large"
                href="/demo"
            >
                Get demo
            </Button>
        </Box>
    )
}

export default HeroSection
