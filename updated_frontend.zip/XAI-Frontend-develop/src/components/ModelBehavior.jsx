import React from 'react'
import {
    Box,
    Typography,
    MenuItem,
    Select,
    Paper,
    Button,
    Divider,
    Grid,
} from '@mui/material'

const dummyFeatures = [
    'Feature A',
    'Feature B',
    'Feature C',
    'Feature D',
    'Feature E',
    'Feature F',
    'Feature G',
    'Feature H',
    'Feature I',
    'Feature J',
]

const FeatureBar = ({ label }) => (
    <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
        <Typography sx={{ width: 100 }} variant="body2" color="textSecondary">
            {label}
        </Typography>
        <Box
            sx={{
                flexGrow: 1,
                bgcolor: '#f0f0f0',
                height: 10,
                borderRadius: 1,
                position: 'relative',
            }}
        >
            <Box
                sx={{
                    width: `${Math.random() * 80 + 10}%`,
                    bgcolor: '#8884d8',
                    height: '100%',
                    borderRadius: 1,
                }}
            />
        </Box>
    </Box>
)

const ModelBehavior = () => {
    const [selectedFeature, setSelectedFeature] = React.useState('Feature A')

    return (
        <Box sx={{ px: 6, py: 4 }}>
            <Typography variant="h5" fontWeight={600} gutterBottom>
                Model Behavior
            </Typography>
            <Typography variant="body2" color="textSecondary" gutterBottom>
                Explore the overall behavior of your model
            </Typography>

            {/* Tab Headings */}
            <Box display="flex" gap={3} mt={3} mb={2}>
                <Typography
                    variant="body2"
                    fontWeight={600}
                    sx={{ cursor: 'pointer', textDecoration: 'underline' }}
                >
                    Feature Importance
                </Typography>
                <Typography variant="body2" color="textSecondary">
                    Partial Dependence Plots
                </Typography>
                <Typography variant="body2" color="textSecondary">
                    SHAP Summary Plots
                </Typography>
            </Box>

            {/* Feature Importance */}
            <Box mt={2}>
                <Typography variant="subtitle1" fontWeight={600} gutterBottom>
                    Feature Importance
                </Typography>
                <Select
                    size="small"
                    value={selectedFeature}
                    onChange={(e) => setSelectedFeature(e.target.value)}
                    sx={{ minWidth: 200, mb: 2 }}
                >
                    {dummyFeatures.map((f) => (
                        <MenuItem key={f} value={f}>
                            {f}
                        </MenuItem>
                    ))}
                </Select>

                <Box>
                    {dummyFeatures.map((f) => (
                        <FeatureBar key={f} label={f} />
                    ))}
                </Box>
            </Box>

            {/* Partial Dependence Plot */}
            <Box mt={6}>
                <Typography variant="subtitle1" fontWeight={600} gutterBottom>
                    Partial Dependence Plots
                </Typography>
                <Select
                    size="small"
                    value={selectedFeature}
                    onChange={(e) => setSelectedFeature(e.target.value)}
                    sx={{ minWidth: 200, mb: 2 }}
                >
                    {dummyFeatures.map((f) => (
                        <MenuItem key={f} value={f}>
                            {f}
                        </MenuItem>
                    ))}
                </Select>

                <Typography variant="body2" color="textSecondary" gutterBottom>
                    Partial Dependence Plot for {selectedFeature}
                </Typography>

                <Box
                    sx={{
                        width: '100%',
                        height: 120,
                        bgcolor: '#f5f5f5',
                        borderRadius: 2,
                        mb: 1,
                    }}
                />

                <Button variant="outlined" size="small">
                    Interpret This Chart (LLM)
                </Button>
            </Box>

            {/* SHAP Summary Plot */}
            <Box mt={6}>
                <Typography variant="subtitle1" fontWeight={600} gutterBottom>
                    SHAP Summary Plots
                </Typography>

                <Typography variant="body2" color="textSecondary" gutterBottom>
                    SHAP Summary Plot
                </Typography>

                <Box
                    sx={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'flex-end',
                        height: 120,
                        mb: 1,
                        px: 1,
                        bgcolor: '#f5f5f5',
                        borderRadius: 2,
                    }}
                >
                    {dummyFeatures.map((feature) => (
                        <Box
                            key={feature}
                            sx={{ textAlign: 'center', width: 30 }}
                        >
                            <Box
                                sx={{
                                    bgcolor: '#8884d8',
                                    height: `${Math.random() * 80 + 20}%`,
                                    mb: 0.5,
                                }}
                            />
                            <Typography variant="caption">{feature}</Typography>
                        </Box>
                    ))}
                </Box>

                <Button variant="outlined" size="small">
                    Interpret This Chart (LLM)
                </Button>
            </Box>
        </Box>
    )
}

export default ModelBehavior
