import React from 'react'
import { ListItem, IconButton, Tooltip } from '@mui/material'
import {
    CloudCircle,
    DriveFolderUpload,
    ArrowDropDownCircle,
    CalendarMonthRounded,
} from '@mui/icons-material'

const iconData = [
    { title: 'Upload splitted dataset', icon: <CloudCircle /> },
    { title: 'Upload single dataset', icon: <DriveFolderUpload /> },
    { title: 'Exclude column in dataset', icon: <ArrowDropDownCircle /> },
    { title: 'Split data by date column', icon: <CalendarMonthRounded /> },
]

/**
 * Renders the list of icons for the closed drawer state.
 * @param {object} props - The component props.
 * @param {Function} props.onIconClick - The function to call when any icon is clicked.
 */
function DrawerIconList({ onIconClick }) {
    return (
        <>
            {iconData.map((item, index) => (
                <ListItem key={index}>
                    <Tooltip title={item.title}>
                        <IconButton
                            onClick={onIconClick}
                            sx={{ color: '#fff' }}
                        >
                            {item.icon}
                        </IconButton>
                    </Tooltip>
                </ListItem>
            ))}
        </>
    )
}

export default DrawerIconList
