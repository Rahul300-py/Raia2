import React from 'react'
import {
    Stack,
    Typography,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    Button,
} from '@mui/material'
import { UploadFileOutlined } from '@mui/icons-material'
import FileUploadBox from './FileUploadBox'

/**
 * A section for uploading train data, test data, and a model file.
 * @param {object} props - The component props.
 * @param {object} props.fileState - An object containing the train, test, and model files.
 * @param {Function} props.handleBrowse - The function for handling file Browse.
 * @param {string} props.modelFormat - The currently selected model format.
 * @param {Function} props.setModelFormat - The function to update the model format.
 * @param {Function} props.handleSaveData - The function to call when the "Upload data" button is clicked.
 */
function ModelUploadSection({
    fileState,
    handleBrowse,
    modelFormat,
    setModelFormat,
    handleSaveData,
}) {
    return (
        <Stack
            direction={{ xs: 'column', sm: 'row' }}
            spacing={3}
            flexWrap="wrap"
            useFlexGap
            my={2}
        >
            <Typography
                variant="subtitle2"
                sx={{ mb: 1, fontWeight: 'bold', width: '100%' }}
            >
                Upload Train/Test Data & Custom Model
            </Typography>
            <FileUploadBox
                title="Drag and drop train file here"
                description="Limit 200MB per file • CSV"
                buttonText="Browse train files"
                onBrowse={() => handleBrowse('train')}
                file={fileState.train}
            />
            <FileUploadBox
                title="Drag and drop test file here"
                description="Limit 200MB per file • CSV"
                buttonText="Browse test files"
                onBrowse={() => handleBrowse('test')}
                file={fileState.test}
            />
            <FormControl fullWidth size="small" sx={{ mb: 0 }}>
                <InputLabel>Model Format</InputLabel>
                <Select
                    value={modelFormat}
                    label="Model Format"
                    onChange={(e) => setModelFormat(e.target.value)}
                >
                    <MenuItem value="onnx">ONNX (.onnx)</MenuItem>
                    <MenuItem value="pkl">Pickle (.pkl)</MenuItem>
                    <MenuItem value="joblib">Joblib (.joblib)</MenuItem>
                </Select>
            </FormControl>
            <Typography
                variant="caption"
                color="text.secondary"
                sx={{
                    fontWeight: 'bold',
                    whiteSpace: 'normal',
                    maxWidth: '100%',
                    my: 0,
                    width: '100%',
                }}
            >
                ⚠️ <strong>ONNX</strong> is preferred to avoid version
                mismatches.
            </Typography>
            <FileUploadBox
                title="Drag and drop model file here"
                description={`Limit 200MB per file • .${modelFormat}`}
                buttonText="Browse model files"
                onBrowse={() => handleBrowse('model', modelFormat)}
                file={fileState.model}
            />
            <Button
                variant="contained"
                startIcon={<UploadFileOutlined />}
                onClick={handleSaveData}
                sx={{
                    width: '100%',
                    padding: 1,
                    backgroundColor: '#232f3e',
                    '&:hover': { backgroundColor: '#3a475b' },
                }}
            >
                Upload data
            </Button>
        </Stack>
    )
}

export default ModelUploadSection
