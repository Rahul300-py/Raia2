import React from 'react'
import { Box, Typography, Button } from '@mui/material'

/**
 * A reusable file upload box with a dashed border.
 * @param {object} props - The component props.
 * @param {string} props.title - The main text, e.g., "Drag and drop train file here".
 * @param {string} props.description - The subtitle, e.g., "Limit 200MB per file • CSV".
 * @param {string} props.buttonText - The text for the browse button.
 * @param {Function} props.onBrowse - The function to call when the button is clicked.
 * @param {object} props.file - The file object to display the name of the selected file.
 */
function FileUploadBox({ title, description, buttonText, onBrowse, file }) {
    return (
        <Box
            sx={{
                border: '2px dashed #ccc',
                borderRadius: '8px',
                p: 2,
                textAlign: 'center',
                mb: 1,
                display: 'flex',
                flexDirection: 'column',
                width: '100%',
            }}
        >
            <Typography variant="body2" color="text.secondary">
                {title}
            </Typography>
            <Typography variant="caption" color="text.secondary">
                {description}
            </Typography>
            <Button
                variant="outlined"
                sx={{ mt: 1, width: '100%' }}
                color="secondary"
                onClick={onBrowse}
            >
                {buttonText}
            </Button>
            {file && (
                <Typography
                    variant="caption"
                    sx={{ mt: 1, wordBreak: 'break-all' }}
                >
                    {file.name}
                </Typography>
            )}
        </Box>
    )
}

export default FileUploadBox
