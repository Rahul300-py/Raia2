import React, { useEffect, useState } from 'react'
import { useSelector } from 'react-redux'
import {
    Box,
    Typography,
    Link,
    Grid,
    Paper,
    ToggleButtonGroup,
    ToggleButton,
    List,
    ListItem,
    ListItemIcon,
    ListItemText,
    Divider,
} from '@mui/material'
import FolderIcon from '@mui/icons-material/Folder'
import InsertDriveFileIcon from '@mui/icons-material/InsertDriveFile'
import ViewModuleIcon from '@mui/icons-material/ViewModule'
import ViewListIcon from '@mui/icons-material/ViewList'

const FileExplorer = () => {
    const { datasets } = useSelector((state) => state.fairness || {})
    const [folderMap, setFolderMap] = useState({})
    const [view, setView] = useState('list')

    useEffect(() => {
        const grouped = {}
        if (datasets?.all) {
            datasets.all.forEach((file) => {
                const folder = file.folder || 'root'
                if (!grouped[folder]) grouped[folder] = []
                grouped[folder].push(file)
            })
        }
        setFolderMap(grouped)
    }, [datasets])

    const handleViewChange = (_, newView) => {
        if (newView !== null) {
            setView(newView)
        }
    }

    return (
        <Box sx={{ width: '100%', maxWidth: 1000, mx: 'auto', mt: 4 }}>
            <Box
                display="flex"
                justifyContent="space-between"
                alignItems="center"
                mb={3}
            >
                <Typography variant="h6">📁 My Uploads</Typography>
                <ToggleButtonGroup
                    value={view}
                    exclusive
                    onChange={handleViewChange}
                    size="small"
                >
                    <ToggleButton value="grid" aria-label="Grid View">
                        <ViewModuleIcon />
                    </ToggleButton>
                    <ToggleButton value="list" aria-label="List View">
                        <ViewListIcon />
                    </ToggleButton>
                </ToggleButtonGroup>
            </Box>

            {Object.entries(folderMap).map(([folderName, files]) => (
                <Box key={folderName} sx={{ mb: 4 }}>
                    <Box display="flex" alignItems="center" mb={1}>
                        <FolderIcon sx={{ mr: 1 }} color="primary" />
                        <Typography variant="subtitle1" fontWeight="bold">
                            {folderName}
                        </Typography>
                    </Box>

                    {view === 'grid' ? (
                        <Grid container spacing={2}>
                            {files.map((file) => (
                                <Grid
                                    item
                                    xs={6}
                                    sm={4}
                                    md={3}
                                    lg={2}
                                    key={file.file_name}
                                >
                                    <Paper
                                        elevation={2}
                                        sx={{
                                            p: 2,
                                            textAlign: 'center',
                                            cursor: 'pointer',
                                            '&:hover': { boxShadow: 4 },
                                        }}
                                    >
                                        <Link
                                            href={file.url}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            underline="none"
                                            color="inherit"
                                            sx={{
                                                display: 'flex',
                                                flexDirection: 'column',
                                                alignItems: 'center',
                                            }}
                                        >
                                            <InsertDriveFileIcon
                                                sx={{ fontSize: 80, mb: 1 }}
                                                color="action"
                                            />
                                            <Typography
                                                variant="body2"
                                                sx={{
                                                    width: '100px',
                                                    fontSize: '0.8rem',
                                                    whiteSpace: 'nowrap',
                                                    overflow: 'hidden',
                                                    textOverflow: 'ellipsis',
                                                    textAlign: 'center',
                                                    cursor: 'default',
                                                }}
                                                title={file.file_name} // 👈 Tooltip on hover
                                            >
                                                {file.file_name}
                                            </Typography>
                                        </Link>
                                    </Paper>
                                </Grid>
                            ))}
                        </Grid>
                    ) : (
                        <Paper variant="outlined">
                            <List dense disablePadding>
                                {files.map((file, idx) => (
                                    <React.Fragment key={file.file_name}>
                                        <ListItem
                                            sx={{
                                                '&:hover': {
                                                    backgroundColor:
                                                        'action.hover',
                                                },
                                            }}
                                            component="a"
                                            href={file.url}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                        >
                                            <ListItemIcon>
                                                <InsertDriveFileIcon />
                                            </ListItemIcon>
                                            <ListItemText
                                                primary={file.file_name}
                                                sx={{ wordBreak: 'break-word' }}
                                            />
                                        </ListItem>
                                        {idx < files.length - 1 && <Divider />}
                                    </React.Fragment>
                                ))}
                            </List>
                        </Paper>
                    )}
                </Box>
            ))}
        </Box>
    )
}

export default FileExplorer
