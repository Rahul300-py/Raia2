import { Box, Grid, Typography, Paper } from '@mui/material'

const features = [
    { title: 'IBC Native', desc: 'Inter-blockchain communication ready.' },
    { title: 'Customizable', desc: 'Built for sovereign appchains.' },
    { title: 'Secure', desc: 'Audited and verified security layers.' },
]

export default function NewFeatures() {
    return (
        <Box
            sx={{
                py: 8,
                px: 2,
                maxWidth: '1200px',
                margin: 'auto',
            }}
        >
            <Typography variant="h4" textAlign="center" mb={4}>
                Key Features
            </Typography>
            <Grid container spacing={4}>
                {features.map((feature, index) => (
                    <Grid item xs={12} md={4} key={index}>
                        <Paper elevation={3} sx={{ p: 4, textAlign: 'center' }}>
                            <Typography variant="h6" fontWeight={700}>
                                {feature.title}
                            </Typography>
                            <Typography sx={{ mt: 2 }}>
                                {feature.desc}
                            </Typography>
                        </Paper>
                    </Grid>
                ))}
            </Grid>
        </Box>
    )
}
