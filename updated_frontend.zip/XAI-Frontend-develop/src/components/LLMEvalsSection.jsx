// src/components/LLMEvalsSection.js
import React from 'react'
import { Box, Typography, Container, Grid, Stack, Link } from '@mui/material'
import EmojiObjectsOutlinedIcon from '@mui/icons-material/EmojiObjectsOutlined' // Placeholder icon
import GppGoodOutlinedIcon from '@mui/icons-material/GppGoodOutlined' // Placeholder icon
import FormatAlignLeftOutlinedIcon from '@mui/icons-material/FormatAlignLeftOutlined' // Placeholder icon
import InsightsOutlinedIcon from '@mui/icons-material/InsightsOutlined' // Placeholder icon
import ThumbsUpDownOutlinedIcon from '@mui/icons-material/ThumbsUpDownOutlined' // Placeholder icon
import RuleOutlinedIcon from '@mui/icons-material/RuleOutlined' // Placeholder icon
import ArrowForwardIcon from '@mui/icons-material/ArrowForward'

const LLMEvalsSection = () => {
    const evalMetrics = [
        {
            icon: <FormatAlignLeftOutlinedIcon />,
            title: 'Adherence to guidelines and format',
        },
        {
            icon: <EmojiObjectsOutlinedIcon />,
            title: 'Hallucinations and factuality',
        },
        { icon: <GppGoodOutlinedIcon />, title: 'PII detection' },
        {
            icon: <InsightsOutlinedIcon />,
            title: 'Retrieval quality and context relevance',
        },
        {
            icon: <ThumbsUpDownOutlinedIcon />,
            title: 'Sentiment, toxicity, tone, trigger words',
        },
        {
            icon: <RuleOutlinedIcon />,
            title: 'Custom evals with any prompt, model, or rule',
        },
    ]

    return (
        <Box
            sx={{
                backgroundColor: 'background.default',
                width: '100%',
                py: { xs: 8, md: 12 },
            }}
        >
            <Container maxWidth="lg">
                <Grid container spacing={5} alignItems="center">
                    <Grid item xs={12} md={6}>
                        <Grid container spacing={4}>
                            {evalMetrics.map((item, index) => (
                                <Grid item xs={12} sm={6} key={index}>
                                    <Stack
                                        direction="row"
                                        spacing={2}
                                        alignItems="center"
                                    >
                                        <Box
                                            sx={{
                                                color: 'highlight.main',
                                                fontSize: 30,
                                            }}
                                        >
                                            {item.icon}
                                        </Box>
                                        <Typography
                                            variant="body1"
                                            sx={{ fontWeight: 500 }}
                                        >
                                            {item.title}
                                        </Typography>
                                    </Stack>
                                </Grid>
                            ))}
                        </Grid>
                    </Grid>
                    <Grid item xs={12} md={6}>
                        <Typography
                            variant="overline"
                            display="block"
                            color="text.secondary"
                            sx={{ mb: 2, textTransform: 'uppercase' }}
                        >
                            LLM Evals
                        </Typography>
                        <Typography
                            variant="h3"
                            component="h2"
                            sx={{ fontWeight: 'bold', lineHeight: 1.2, mb: 3 }}
                        >
                            Track what matters for{' '}
                            <Box
                                component="span"
                                sx={{ color: 'secondary.main' }}
                            >
                                your AI use case
                            </Box>
                        </Typography>
                        <Typography
                            variant="body1"
                            sx={{ color: 'text.secondary', mb: 4 }}
                        >
                            Easily design your own AI quality system. Use the
                            library of 100+ in-built metrics, or add custom
                            ones. Combine rules, classifiers, and LLM-based
                            evaluations.
                        </Typography>
                        <Link
                            href="#"
                            sx={{
                                display: 'inline-flex',
                                alignItems: 'center',
                                color: 'highlight.main',
                                fontWeight: 'bold',
                            }}
                        >
                            Learn more{' '}
                            <ArrowForwardIcon
                                sx={{ ml: 0.5, fontSize: '1em' }}
                            />
                        </Link>
                    </Grid>
                </Grid>
            </Container>
        </Box>
    )
}

export default LLMEvalsSection
