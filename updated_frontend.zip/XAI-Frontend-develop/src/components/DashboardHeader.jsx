import React from 'react'
import { Box, Paper, Tabs, Tab, Typography, Button, Stack } from '@mui/material'
import { ArrowBack } from '@mui/icons-material'
import LightbulbIcon from '@mui/icons-material/Lightbulb'

const DashboardHeader = ({
    activeTab,
    handleTabChange,
    tabLabels,
    open,
    logoSrc,
    handleGoBack,
    selectedProject,
    setSelectedProject,
    showExplainButton = false,
    onExplainClick,
}) => {
    return (
        <>
            <Paper
                elevation={0}
                sx={{
                    borderBottom: 1,
                    borderColor: 'divider',
                    borderRadius: '0px',
                    bgcolor: 'primary.dark',
                    padding: '8px',
                    display: 'flex',
                    flexDirection: 'row',
                }}
            >
                {!open && (
                    <Box
                        sx={{
                            display: 'flex',
                            alignItems: 'center',
                            mb: '6px',
                        }}
                    >
                        <img
                            src={logoSrc}
                            alt="RAIA Logo"
                            style={{ width: '100px' }}
                        />
                    </Box>
                )}
                <Tabs
                    value={activeTab}
                    onChange={handleTabChange}
                    aria-label="dashboard sections"
                    variant="scrollable"
                    scrollButtons="auto"
                    allowScrollButtonsMobile
                    sx={{
                        '& .MuiTabs-indicator': {
                            backgroundColor: 'primary.dark',
                        },
                        '& .MuiTab-root': {
                            textTransform: 'none',
                            fontWeight: 600,
                            color: '#fff',
                        },
                        '& .Mui-selected': {
                            color: 'rgb(186, 195, 255)',
                            fontWeight: 700,
                        },
                    }}
                >
                    {tabLabels.map((label, index) => (
                        <Tab key={index} label={label} />
                    ))}
                </Tabs>
            </Paper>

            {/* Breadcrumb and Action Bar */}
            <Box
                sx={{
                    p: 3,
                    pb: 0,
                    bgcolor: 'background.paper',
                }}
            >
                <Stack flexDirection="row" justifyContent="space-between">
                    <Stack
                        flexDirection="row"
                        alignItems="center"
                        sx={{ color: 'primary.dark' }}
                    >
                        <ArrowBack fontSize="20px" sx={{ mr: '4px' }} />
                        <Typography variant="subtitle2">
                            <Button
                                variant="text"
                                color="primary.dark"
                                onClick={handleGoBack}
                            >
                                Home
                            </Button>
                            /
                            <Button
                                variant="text"
                                color="primary.dark"
                                onClick={() => setSelectedProject(null)}
                            >
                                Dashboard
                            </Button>
                            / <Button>{tabLabels[activeTab]}</Button>
                        </Typography>
                    </Stack>
                    {showExplainButton && (
                        <Button
                            onClick={onExplainClick}
                            variant="contained"
                            startIcon={<LightbulbIcon />}
                            sx={{ mb: 2 }}
                        >
                            Explain with AI
                        </Button>
                    )}
                </Stack>
            </Box>
        </>
    )
}

export default DashboardHeader
