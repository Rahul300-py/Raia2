import React from 'react'
import {
    Box,
    Button,
    TextField,
    Typography,
    List,
    ListItem,
    ListItemText,
    IconButton,
} from '@mui/material'
import ChatIcon from '@mui/icons-material/Chat'
import CloseIcon from '@mui/icons-material/Close'
import DashboardNavBar from './DashboardNavbar'
import { useSelector } from 'react-redux'

export default function ModelExplainibility() {
    const { regressionModelExplainibility } = useSelector(
        (state) => state.regression
    )

    const explainer_url = regressionModelExplainibility?.explainer_url?.replace(
        'http://http://',
        'http://'
    )
    return (
        <Box sx={{ display: 'flex', height: '100vh', overflow: 'hidden' }}>
            {/* Left: iframe area */}
            <Box
                sx={{
                    flex: '1 1 100%',
                    transition: 'flex 0.3s ease',
                    borderRight: 'none',
                }}
            >
                <Typography>{explainer_url}</Typography>
                <iframe
                    src={explainer_url}
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                />
            </Box>
        </Box>
    )
}
