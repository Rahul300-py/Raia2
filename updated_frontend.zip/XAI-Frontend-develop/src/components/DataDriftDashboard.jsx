import React, { useState } from 'react'
import {
    Box,
    Typography,
    Paper,
    TextField,
    InputAdornment,
    IconButton,
    Alert,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    Button,
    Container,
} from '@mui/material'
import SearchIcon from '@mui/icons-material/Search'
import PlayArrowIcon from '@mui/icons-material/PlayArrow'
import CloseIcon from '@mui/icons-material/Close'
import { DataGrid } from '@mui/x-data-grid'
import { CropFree } from '@mui/icons-material'

// --- Dummy Data (keep as is) ---
const generateDummyHistogramData = (length = 10) =>
    Array.from({ length }).map(() => Math.floor(Math.random() * 90) + 10)

const referencePreviewData = [
    {
        id: 1,
        age: 59,
        job: 'admin.',
        marital: 'married',
        education: 'secondary',
        default: 'no',
        balance: 2340,
        housing: 'yes',
        loan: 'no',
        contact: 'unknown',
        day: 5,
        month: 'may',
        duration: 261,
        campaign: 1,
        pdays: -1,
        previous: 0,
        poutcome: 'unknown',
        feature1: 'val1',
        feature2: 'val2',
        feature3: 'val3',
        feature4: 'val4',
    },
    {
        id: 2,
        age: 54,
        job: 'admin.',
        marital: 'married',
        education: 'secondary',
        default: 'no',
        balance: 45,
        housing: 'no',
        loan: 'no',
        contact: 'unknown',
        day: 5,
        month: 'may',
        duration: 139,
        campaign: 1,
        pdays: -1,
        previous: 0,
        poutcome: 'unknown',
        feature1: 'val1',
        feature2: 'val2',
        feature3: 'val3',
        feature4: 'val4',
    },
    {
        id: 3,
        age: 39,
        job: 'technician',
        marital: 'married',
        education: 'secondary',
        default: 'no',
        balance: 127,
        housing: 'yes',
        loan: 'no',
        contact: 'unknown',
        day: 5,
        month: 'may',
        duration: 182,
        campaign: 1,
        pdays: -1,
        previous: 0,
        poutcome: 'unknown',
        feature1: 'val1',
        feature2: 'val2',
        feature3: 'val3',
        feature4: 'val4',
    },
    {
        id: 4,
        age: 55,
        job: 'services',
        marital: 'married',
        education: 'secondary',
        default: 'no',
        balance: 3476,
        housing: 'yes',
        loan: 'no',
        contact: 'unknown',
        day: 5,
        month: 'may',
        duration: 104,
        campaign: 1,
        pdays: -1,
        previous: 0,
        poutcome: 'unknown',
        feature1: 'val1',
        feature2: 'val2',
        feature3: 'val3',
        feature4: 'val4',
    },
    {
        id: 5,
        age: 54,
        job: 'admin.',
        marital: 'married',
        education: 'tertiary',
        default: 'no',
        balance: 289,
        housing: 'no',
        loan: 'no',
        contact: 'unknown',
        day: 5,
        month: 'may',
        duration: 281,
        campaign: 1,
        pdays: -1,
        previous: 0,
        poutcome: 'unknown',
        feature1: 'val1',
        feature2: 'val2',
        feature3: 'val3',
        feature4: 'val4',
    },
    {
        id: 6,
        age: 30,
        job: 'unemployed',
        marital: 'single',
        education: 'tertiary',
        default: 'no',
        balance: 100,
        housing: 'no',
        loan: 'no',
        contact: 'cellular',
        day: 10,
        month: 'jun',
        duration: 50,
        campaign: 2,
        pdays: -1,
        previous: 0,
        poutcome: 'unknown',
        feature1: 'val1',
        feature2: 'val2',
        feature3: 'val3',
        feature4: 'val4',
    },
    {
        id: 7,
        age: 45,
        job: 'management',
        marital: 'married',
        education: 'tertiary',
        default: 'no',
        balance: 500,
        housing: 'yes',
        loan: 'no',
        contact: 'telephone',
        day: 15,
        month: 'jul',
        duration: 90,
        campaign: 1,
        pdays: 120,
        previous: 1,
        poutcome: 'success',
        feature1: 'val1',
        feature2: 'val2',
        feature3: 'val3',
        feature4: 'val4',
    },
    {
        id: 8,
        age: 28,
        job: 'student',
        marital: 'single',
        education: 'secondary',
        default: 'no',
        balance: 1200,
        housing: 'no',
        loan: 'no',
        contact: 'unknown',
        day: 20,
        month: 'aug',
        duration: 150,
        campaign: 3,
        pdays: -1,
        previous: 0,
        poutcome: 'unknown',
        feature1: 'val1',
        feature2: 'val2',
        feature3: 'val3',
        feature4: 'val4',
    },
    {
        id: 9,
        age: 60,
        job: 'retired',
        marital: 'married',
        education: 'primary',
        default: 'no',
        balance: 3000,
        housing: 'no',
        loan: 'no',
        contact: 'cellular',
        day: 25,
        month: 'sep',
        duration: 200,
        campaign: 1,
        pdays: 180,
        previous: 2,
        poutcome: 'failure',
        feature1: 'val1',
        feature2: 'val2',
        feature3: 'val3',
        feature4: 'val4',
    },
    {
        id: 10,
        age: 35,
        job: 'technician',
        marital: 'single',
        education: 'secondary',
        default: 'no',
        balance: 800,
        housing: 'yes',
        loan: 'yes',
        contact: 'cellular',
        day: 30,
        month: 'oct',
        duration: 70,
        campaign: 4,
        pdays: -1,
        previous: 0,
        poutcome: 'unknown',
        feature1: 'val1',
        feature2: 'val2',
        feature3: 'val3',
        feature4: 'val4',
    },
]

const currentPreviewData = [
    {
        id: 1,
        age: 59,
        job: 'admin.',
        marital: 'single',
        education: 'tertiary',
        default: 'no',
        balance: 1324,
        housing: 'yes',
        loan: 'no',
        contact: 'cellular',
        day: 23,
        month: 'jan',
        duration: 132,
        campaign: 2,
        pdays: -1,
        previous: 0,
        poutcome: 'unknown',
        new_feature1: 'abc',
        new_feature2: 'def',
        new_feature3: 'ghi',
        new_feature4: 'jkl',
    },
    {
        id: 2,
        age: 32,
        job: 'technician',
        marital: 'married',
        education: 'tertiary',
        default: 'no',
        balance: 524,
        housing: 'no',
        loan: 'yes',
        contact: 'cellular',
        day: 23,
        month: 'may',
        duration: 107,
        campaign: 4,
        pdays: 183,
        previous: 1,
        poutcome: 'failure',
        new_feature1: 'abc',
        new_feature2: 'def',
        new_feature3: 'ghi',
        new_feature4: 'jkl',
    },
    {
        id: 3,
        age: 41,
        job: 'blue-collar',
        marital: 'single',
        education: 'secondary',
        default: 'no',
        balance: 285,
        housing: 'no',
        loan: 'no',
        contact: 'cellular',
        day: 23,
        month: 'oct',
        duration: 63,
        campaign: 2,
        pdays: -1,
        previous: 0,
        poutcome: 'unknown',
        new_feature1: 'abc',
        new_feature2: 'def',
        new_feature3: 'ghi',
        new_feature4: 'jkl',
    },
    {
        id: 4,
        age: 35,
        job: 'services',
        marital: 'married',
        education: 'secondary',
        default: 'no',
        balance: 390,
        housing: 'no',
        loan: 'no',
        contact: 'cellular',
        day: 23,
        month: 'aug',
        duration: 106,
        campaign: 1,
        pdays: -1,
        previous: 0,
        poutcome: 'unknown',
        new_feature1: 'abc',
        new_feature2: 'def',
        new_feature3: 'ghi',
        new_feature4: 'jkl',
    },
    {
        id: 5,
        age: 34,
        job: 'management',
        marital: 'single',
        education: 'tertiary',
        default: 'no',
        balance: 404,
        housing: 'yes',
        loan: 'no',
        contact: 'cellular',
        day: 5,
        month: 'feb',
        duration: 22,
        campaign: 1,
        pdays: -1,
        previous: 0,
        poutcome: 'unknown',
        new_feature1: 'abc',
        new_feature2: 'def',
        new_feature3: 'ghi',
        new_feature4: 'jkl',
    },
    {
        id: 6,
        age: 40,
        job: 'entrepreneur',
        marital: 'married',
        education: 'tertiary',
        default: 'no',
        balance: 600,
        housing: 'no',
        loan: 'no',
        contact: 'unknown',
        day: 12,
        month: 'mar',
        duration: 80,
        campaign: 2,
        pdays: -1,
        previous: 0,
        poutcome: 'unknown',
        new_feature1: 'abc',
        new_feature2: 'def',
        new_feature3: 'ghi',
        new_feature4: 'jkl',
    },
    {
        id: 7,
        age: 29,
        job: 'blue-collar',
        marital: 'single',
        education: 'secondary',
        default: 'no',
        balance: 150,
        housing: 'yes',
        loan: 'no',
        contact: 'cellular',
        day: 18,
        month: 'apr',
        duration: 110,
        campaign: 1,
        pdays: -1,
        previous: 0,
        poutcome: 'unknown',
        new_feature1: 'abc',
        new_feature2: 'def',
        new_feature3: 'ghi',
        new_feature4: 'jkl',
    },
    {
        id: 8,
        age: 50,
        job: 'housemaid',
        marital: 'married',
        education: 'primary',
        default: 'no',
        balance: 200,
        housing: 'no',
        loan: 'yes',
        contact: 'telephone',
        day: 22,
        month: 'jun',
        duration: 95,
        campaign: 3,
        pdays: 90,
        previous: 1,
        poutcome: 'success',
        new_feature1: 'abc',
        new_feature2: 'def',
        new_feature3: 'ghi',
        new_feature4: 'jkl',
    },
    {
        id: 9,
        age: 25,
        job: 'student',
        marital: 'single',
        education: 'tertiary',
        default: 'no',
        balance: 700,
        housing: 'no',
        loan: 'no',
        contact: 'cellular',
        day: 7,
        month: 'jul',
        duration: 130,
        campaign: 1,
        pdays: -1,
        previous: 0,
        poutcome: 'unknown',
        new_feature1: 'abc',
        new_feature2: 'def',
        new_feature3: 'ghi',
        new_feature4: 'jkl',
    },
    {
        id: 10,
        age: 55,
        job: 'retired',
        marital: 'married',
        education: 'secondary',
        default: 'no',
        balance: 2500,
        housing: 'no',
        loan: 'no',
        contact: 'unknown',
        day: 14,
        month: 'aug',
        duration: 180,
        campaign: 2,
        pdays: 60,
        previous: 1,
        poutcome: 'failure',
        new_feature1: 'abc',
        new_feature2: 'def',
        new_feature3: 'ghi',
        new_feature4: 'jkl',
    },
]

const driftData = [
    {
        id: 1,
        column: 'deposit',
        type: 'cat',
        referenceDistribution: generateDummyHistogramData(),
        currentDistribution: generateDummyHistogramData(),
        dataDrift: 'Detected',
        statTest: 'Jensen-Shannon distance',
        driftScore: 0.767549,
    },
    {
        id: 2,
        column: 'duration',
        type: 'num',
        referenceDistribution: generateDummyHistogramData(),
        currentDistribution: generateDummyHistogramData(),
        dataDrift: 'Detected',
        statTest: 'Wasserstein distance (normed)',
        driftScore: 0.755779,
    },
    {
        id: 3,
        column: 'campaign',
        type: 'num',
        referenceDistribution: generateDummyHistogramData(),
        currentDistribution: generateDummyHistogramData(),
        dataDrift: 'Detected',
        statTest: 'Wasserstein distance (normed)',
        driftScore: 0.358796,
    },
    {
        id: 4,
        column: 'pdays',
        type: 'num',
        referenceDistribution: generateDummyHistogramData(),
        currentDistribution: generateDummyHistogramData(),
        dataDrift: 'Detected',
        statTest: 'Wasserstein distance (normed)',
        driftScore: 0.267822,
    },
    {
        id: 5,
        column: 'previous',
        type: 'num',
        referenceDistribution: generateDummyHistogramData(),
        currentDistribution: generateDummyHistogramData(),
        dataDrift: 'Detected',
        statTest: 'Wasserstein distance (normed)',
        driftScore: 0.245844,
    },
    {
        id: 6,
        column: 'poutcome',
        type: 'cat',
        referenceDistribution: generateDummyHistogramData(),
        currentDistribution: generateDummyHistogramData(),
        dataDrift: 'Detected',
        statTest: 'Jensen-Shannon distance',
        driftScore: 0.215511,
    },
    {
        id: 7,
        column: 'month',
        type: 'cat',
        referenceDistribution: generateDummyHistogramData(),
        currentDistribution: generateDummyHistogramData(),
        dataDrift: 'Detected',
        statTest: 'Jensen-Shannon distance',
        driftScore: 0.213696,
    },
    {
        id: 8,
        column: 'contact',
        type: 'cat',
        referenceDistribution: generateDummyHistogramData(),
        currentDistribution: generateDummyHistogramData(),
        dataDrift: 'Detected',
        statTest: 'Jensen-Shannon distance',
        driftScore: 0.175976,
    },
    {
        id: 9,
        column: 'age',
        type: 'num',
        referenceDistribution: generateDummyHistogramData(),
        currentDistribution: generateDummyHistogramData(),
        dataDrift: 'Detected',
        statTest: 'Wasserstein distance',
        driftScore: 0.175858,
    },
    // Add more dummy data for scrollability demonstration
    {
        id: 10,
        column: 'balance',
        type: 'num',
        referenceDistribution: generateDummyHistogramData(),
        currentDistribution: generateDummyHistogramData(),
        dataDrift: 'Detected',
        statTest: 'Wasserstein distance',
        driftScore: 0.15,
    },
    {
        id: 11,
        column: 'housing',
        type: 'cat',
        referenceDistribution: generateDummyHistogramData(),
        currentDistribution: generateDummyHistogramData(),
        dataDrift: 'No Drift',
        statTest: 'Jensen-Shannon distance',
        driftScore: 0.05,
    },
    {
        id: 12,
        column: 'loan',
        type: 'cat',
        referenceDistribution: generateDummyHistogramData(),
        currentDistribution: generateDummyHistogramData(),
        dataDrift: 'No Drift',
        statTest: 'Jensen-Shannon distance',
        driftScore: 0.03,
    },
    {
        id: 13,
        column: 'job',
        type: 'cat',
        referenceDistribution: generateDummyHistogramData(),
        currentDistribution: generateDummyHistogramData(),
        dataDrift: 'Detected',
        statTest: 'Jensen-Shannon distance',
        driftScore: 0.19,
    },
    {
        id: 14,
        column: 'marital',
        type: 'cat',
        referenceDistribution: generateDummyHistogramData(),
        currentDistribution: generateDummyHistogramData(),
        dataDrift: 'No Drift',
        statTest: 'Jensen-Shannon distance',
        driftScore: 0.08,
    },
    {
        id: 15,
        column: 'education',
        type: 'cat',
        referenceDistribution: generateDummyHistogramData(),
        currentDistribution: generateDummyHistogramData(),
        dataDrift: 'Detected',
        statTest: 'Jensen-Shannon distance',
        driftScore: 0.23,
    },
    {
        id: 16,
        column: 'default',
        type: 'cat',
        referenceDistribution: generateDummyHistogramData(),
        currentDistribution: generateDummyHistogramData(),
        dataDrift: 'No Drift',
        statTest: 'Jensen-Shannon distance',
        driftScore: 0.01,
    },
    {
        id: 17,
        column: 'day',
        type: 'num',
        referenceDistribution: generateDummyHistogramData(),
        currentDistribution: generateDummyHistogramData(),
        dataDrift: 'Detected',
        statTest: 'Wasserstein distance',
        driftScore: 0.2,
    },
]

// --- Histogram Chart Component (keep as is) ---
const HistogramChart = ({ data, color }) => {
    if (!Array.isArray(data) || data.length === 0) {
        return (
            <Box
                sx={{
                    width: '100%',
                    height: 40,
                    backgroundColor: 'lightgrey',
                    borderRadius: 1,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: '0.7em',
                    color: 'grey',
                }}
            >
                No data
            </Box>
        )
    }

    const maxValue = Math.max(...data)

    return (
        <Box
            sx={{
                width: '100%',
                height: 40,
                backgroundColor: color,
                borderRadius: 1,
                opacity: 0.7,
                display: 'flex',
                alignItems: 'flex-end',
                justifyContent: 'space-between',
                overflow: 'hidden',
                p: 0.5,
            }}
        >
            {data.map((value, index) => (
                <Box
                    key={index}
                    sx={{
                        width: `${100 / data.length - 1}%`,
                        backgroundColor: '#ee0400',
                        height: `${(value / maxValue) * 80 + 20}%`,
                        borderRadius: '2px 2px 0 0',
                    }}
                />
            ))}
        </Box>
    )
}

// --- Full Table Modal Component (keep as is) ---
const FullTableModal = ({ open, handleClose, title, data, columns }) => {
    return (
        <Dialog open={open} onClose={handleClose} maxWidth="xl" fullWidth>
            <DialogTitle>
                <Box
                    sx={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                    }}
                >
                    {title}
                    <IconButton aria-label="close" onClick={handleClose}>
                        <CloseIcon />
                    </IconButton>
                </Box>
            </DialogTitle>
            <DialogContent dividers>
                <TableContainer
                    sx={{ maxHeight: 'calc(100vh - 200px)', overflowX: 'auto' }}
                >
                    <Table stickyHeader size="small">
                        <TableHead>
                            <TableRow>
                                {columns.map((col) => (
                                    <TableCell
                                        key={col}
                                        sx={{
                                            fontWeight: 'bold',
                                            minWidth: 100,
                                        }}
                                    >
                                        {col}
                                    </TableCell>
                                ))}
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {data.map((row) => (
                                <TableRow key={row.id}>
                                    {columns.map((col) => (
                                        <TableCell key={col}>
                                            {row[col]}
                                        </TableCell>
                                    ))}
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </TableContainer>
            </DialogContent>
            <DialogActions>
                <Button onClick={handleClose}>Close</Button>
            </DialogActions>
        </Dialog>
    )
}

// --- Main Dashboard Component ---
const MLDataDriftDashboard = () => {
    const [searchText, setSearchText] = useState('')
    const [openReferenceModal, setOpenReferenceModal] = useState(false)
    const [openCurrentModal, setOpenCurrentModal] = useState(false)

    const handleOpenReferenceModal = () => setOpenReferenceModal(true)
    const handleCloseReferenceModal = () => setOpenReferenceModal(false)

    const handleOpenCurrentModal = () => setOpenCurrentModal(true)
    const handleCloseCurrentModal = () => setOpenCurrentModal(false)

    const getAllColumnNames = (data) => {
        if (!data || data.length === 0) return []
        const allKeys = new Set()
        data.forEach((item) => {
            Object.keys(item).forEach((key) => {
                if (key !== 'id') allKeys.add(key)
            })
        })
        return Array.from(allKeys)
    }

    const referencePreviewColumns = getAllColumnNames(referencePreviewData)
    const currentPreviewColumns = getAllColumnNames(currentPreviewData)

    // --- Calculate summary data from driftData ---
    const totalColumns = driftData.length
    const driftedColumnsCount = driftData.filter(
        (column) => column.dataDrift === 'Detected'
    ).length
    const shareOfDriftedColumns =
        totalColumns > 0 ? (driftedColumnsCount / totalColumns).toFixed(3) : 0
    const shareOfDriftedColumnsPercentage = (
        shareOfDriftedColumns * 100
    ).toFixed(2)

    // --- UPDATED DataGrid Columns ---
    const columns = [
        {
            field: 'column',
            headerName: 'Column',
            flex: 1, // This column will grow to fill available space
            minWidth: 150, // Ensures it's at least this wide
            renderCell: (params) => (
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    {params.value}
                </Box>
            ),
        },
        { field: 'type', headerName: 'Type', width: 80 }, // Fixed width, small content
        {
            field: 'referenceDistribution',
            headerName: 'Reference Distribution',
            width: 200, // Fixed width to properly show the chart
            sortable: false,
            renderCell: (params) => (
                <HistogramChart data={params.value} color="#fff" />
            ),
        },
        {
            field: 'currentDistribution',
            headerName: 'Current Distribution',
            width: 200, // Fixed width to properly show the chart
            sortable: false,
            renderCell: (params) => (
                <HistogramChart data={params.value} color="#fff" />
            ),
        },
        { field: 'dataDrift', headerName: 'Data Drift', width: 120 }, // Fixed width for clear status
        {
            field: 'statTest',
            headerName: 'Stat Test',
            flex: 1.5, // Can grow more than 'column' if needed
            minWidth: 250, // Ensures it's at least this wide
        },
        {
            field: 'driftScore',
            headerName: 'Drift Score',
            type: 'number',
            width: 120, // Fixed width for a number
            // Optionally, if you want it to align right or have custom styling
            // headerAlign: 'right',
            // align: 'right',
        },
    ]

    const filteredRows = driftData.filter((row) =>
        Object.values(row).some((value) =>
            String(Array.isArray(value) ? value.join(' ') : value)
                .toLowerCase()
                .includes(searchText.toLowerCase())
        )
    )

    return (
        <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
            {/* Top Bar */}
            <Box
                sx={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    mb: 3,
                    flexWrap: 'wrap',
                    gap: 2,
                }}
            >
                <Typography variant="h5" sx={{ fontWeight: 'medium' }}>
                    Data Drift Column Explorer
                </Typography>

                <Button
                    variant="contained"
                    startIcon={<PlayArrowIcon />}
                    sx={{ mb: { xs: 0, sm: 2 } }}
                >
                    Explain with AI
                </Button>
            </Box>

            {/* Previews */}
            <Box
                sx={{
                    display: 'flex',
                    flexWrap: 'wrap',
                    gap: 3,
                    mb: 3,
                }}
            >
                {[
                    {
                        label: 'Reference',
                        data: referencePreviewData,
                        cols: referencePreviewColumns,
                        handler: handleOpenReferenceModal,
                    },
                    {
                        label: 'Current',
                        data: currentPreviewData,
                        cols: currentPreviewColumns,
                        handler: handleOpenCurrentModal,
                    },
                ].map(({ label, data, cols, handler }, idx) => (
                    <Paper
                        key={idx}
                        elevation={1}
                        sx={{
                            p: 2,
                            flex: 1,
                            minWidth: 300,
                            overflow: 'hidden',
                        }}
                    >
                        <Box
                            sx={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                mb: 1,
                            }}
                        >
                            <Typography
                                variant="subtitle1"
                                sx={{ fontWeight: 'bold' }}
                            >
                                {label} preview
                            </Typography>
                            <IconButton
                                size="small"
                                onClick={handler}
                                aria-label={`expand ${label.toLowerCase()} preview`}
                            >
                                <CropFree fontSize="small" />
                            </IconButton>
                        </Box>
                        <TableContainer
                            sx={{ maxHeight: 200, overflowX: 'auto' }}
                        >
                            <Table size="small" stickyHeader>
                                <TableHead>
                                    <TableRow>
                                        {cols.map((col) => (
                                            <TableCell
                                                key={col}
                                                sx={{
                                                    fontWeight: 'bold',
                                                    minWidth: 80,
                                                }}
                                            >
                                                {col}
                                            </TableCell>
                                        ))}
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {data.map((row) => (
                                        <TableRow key={row.id}>
                                            {cols.map((col) => (
                                                <TableCell key={col}>
                                                    {row[col]}
                                                </TableCell>
                                            ))}
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </TableContainer>
                    </Paper>
                ))}
            </Box>

            {/* Drift Summary */}
            <Box sx={{ mb: 3 }}>
                <Typography variant="h6" gutterBottom>
                    Full Drift Summary (All Columns)
                </Typography>
                <Typography variant="body1">
                    <Box component="span" sx={{ fontWeight: 'bold' }}>
                        {driftedColumnsCount}
                    </Box>{' '}
                    out of{' '}
                    <Box component="span" sx={{ fontWeight: 'bold' }}>
                        {totalColumns}
                    </Box>{' '}
                    columns have detected drift.
                </Typography>
            </Box>

            {/* Dataset Drift Block */}
            <Paper elevation={2} sx={{ p: 2, mb: 3, textAlign: 'center' }}>
                <Typography variant="h6" gutterBottom>
                    Dataset Drift
                </Typography>
                <Typography variant="body2">
                    Dataset Drift is{' '}
                    {driftedColumnsCount > 0 ? 'detected' : 'not detected'}.
                    Dataset drift detection threshold is 0.5
                </Typography>

                <Box
                    sx={{
                        display: 'flex',
                        justifyContent: 'space-around',
                        flexWrap: 'wrap',
                        gap: 2,
                        mt: 3,
                        px: 2,
                    }}
                >
                    {[
                        { label: 'Columns', value: totalColumns },
                        {
                            label: 'Drifted Columns',
                            value: driftedColumnsCount,
                        },
                        {
                            label: 'Share of Drifted Columns',
                            value: shareOfDriftedColumns,
                        },
                    ].map((item) => (
                        <Box key={item.label} sx={{ textAlign: 'center' }}>
                            <Typography
                                variant="h4"
                                sx={{ fontWeight: 'bold' }}
                            >
                                {item.value}
                            </Typography>
                            <Typography variant="body2" color="text.secondary">
                                {item.label}
                            </Typography>
                        </Box>
                    ))}
                </Box>
            </Paper>

            {/* Share Summary */}
            <Paper elevation={2} sx={{ p: 2, mb: 3 }}>
                <Typography variant="h6">
                    Drift is detected for{' '}
                    <Box component="span" sx={{ fontWeight: 'bold' }}>
                        {shareOfDriftedColumnsPercentage}%
                    </Box>{' '}
                    of columns ({driftedColumnsCount} out of {totalColumns}).
                </Typography>
            </Paper>

            {/* Search */}
            <Box sx={{ display: 'flex', justifyContent: 'flex-end', mb: 2 }}>
                <TextField
                    variant="outlined"
                    size="small"
                    placeholder="Search..."
                    value={searchText}
                    onChange={(e) => setSearchText(e.target.value)}
                    InputProps={{
                        startAdornment: (
                            <InputAdornment position="start">
                                <SearchIcon />
                            </InputAdornment>
                        ),
                    }}
                />
            </Box>

            {/* Data Grid */}
            <Paper
                elevation={2}
                sx={{ height: 600, width: '100%', overflow: 'hidden' }}
            >
                <DataGrid
                    rows={filteredRows}
                    columns={columns}
                    initialState={{
                        pagination: {
                            paginationModel: { page: 0, pageSize: 10 },
                        },
                    }}
                    pageSizeOptions={[5, 10, 20]}
                    disableRowSelectionOnClick
                    sx={{
                        '& .MuiDataGrid-columnHeaders': {
                            backgroundColor: '#f5f5f5',
                            fontWeight: 'bold',
                        },
                        '& .MuiDataGrid-virtualScrollerRenderZone': {
                            '&::-webkit-scrollbar': {
                                height: '8px',
                                width: '8px',
                            },
                            '&::-webkit-scrollbar-thumb': {
                                backgroundColor: 'rgba(0,0,0,.2)',
                                borderRadius: '10px',
                            },
                            '&::-webkit-scrollbar-track': {
                                backgroundColor: 'transparent',
                            },
                        },
                    }}
                />
            </Paper>

            {/* Modals */}
            <FullTableModal
                open={openReferenceModal}
                handleClose={handleCloseReferenceModal}
                title="Reference Preview - Full View"
                data={referencePreviewData}
                columns={referencePreviewColumns}
            />
            <FullTableModal
                open={openCurrentModal}
                handleClose={handleCloseCurrentModal}
                title="Current Preview - Full View"
                data={currentPreviewData}
                columns={currentPreviewColumns}
            />
        </Container>
    )
}

export default MLDataDriftDashboard
