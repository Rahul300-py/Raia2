import React from 'react'
import {
    Box,
    Typography,
    LinearProgress,
    Stack,
    List,
    ListItem,
    ListItemIcon,
    ListItemText,
    useTheme,
    Grow,
    Slide,
} from '@mui/material'
import {
    Memory as MemoryIcon, // Brain/processing
    NetworkPing as NetworkPingIcon, // Data flow/connectivity
    ModelTraining as ModelTrainingIcon, // ML model training
    Insights as InsightsIcon, // General insights
    QueryStats as QueryStatsIcon, // Data querying/stats
    Science as ScienceIcon, // Research/advanced methods
    GppGood as GppGoodIcon, // Verification/validation
    DataArray as DataArrayIcon, // Data arrays/structures
    AutoAwesome as AutoAwesomeIcon,
    Lightbulb, // AI/magic touch
} from '@mui/icons-material'

// Default dataset information if none is provided
const defaultDatasetInfo = {
    recordCount: 'vast amounts of',
    mainFeatures: ['complex variables', 'interconnected attributes'],
    targetVariable: 'key outcomes',
}

// Array of icons to cycle through for the main animation
const animatingIcons = [
    <MemoryIcon />,
    <NetworkPingIcon />,
    <ModelTrainingIcon />,
    <QueryStatsIcon />,
    <DataArrayIcon />,
]

const SummaryLoaderPlaceholder = ({ datasetInfo = defaultDatasetInfo }) => {
    const theme = useTheme()
    const [currentFactIndex, setCurrentFactIndex] = React.useState(0)
    const [currentIconIndex, setCurrentIconIndex] = React.useState(0)

    // Generalized loading facts with AI-centric language
    const loadingFacts = React.useMemo(
        () => [
            {
                icon: <DataArrayIcon color="primary" />,
                text: `Ingesting and structuring ${datasetInfo.recordCount} data points.`,
            },
            {
                icon: <QueryStatsIcon color="secondary" />,
                text: `Performing deep-dive statistical analysis and pattern recognition.`,
            },
            {
                icon: <ModelTrainingIcon color="info" />,
                text: `Training advanced machine learning models for ${datasetInfo.targetVariable} prediction.`,
            },
            {
                icon: <Lightbulb color="success" />, // Keep Lightbulb, it's good for insight
                text: `Uncovering latent correlations between ${datasetInfo.mainFeatures[0]} and ${datasetInfo.mainFeatures[1]}.`,
            },
            {
                icon: <NetworkPingIcon color="warning" />,
                text: `Validating model integrity and ensuring robust performance.`,
            },
            {
                icon: <GppGoodIcon color="error" />, // Checkmark for validation
                text: 'Calibrating parameters for optimal predictive accuracy.',
            },
            {
                icon: <InsightsIcon color="primary" />,
                text: 'Synthesizing actionable insights from complex data structures.',
            },
        ],
        [datasetInfo]
    )

    // Effect to cycle through facts
    React.useEffect(() => {
        const factInterval = setInterval(() => {
            setCurrentFactIndex(
                (prevIndex) => (prevIndex + 1) % loadingFacts.length
            )
        }, 4500) // Slightly longer for more time to read
        return () => clearInterval(factInterval)
    }, [loadingFacts])

    // Effect to cycle through main animating icons
    React.useEffect(() => {
        const iconInterval = setInterval(() => {
            setCurrentIconIndex(
                (prevIndex) => (prevIndex + 1) % animatingIcons.length
            )
        }, 2500) // Slightly slower for less frantic feel
        return () => clearInterval(iconInterval)
    }, [])

    const currentFact = loadingFacts[currentFactIndex]
    const CurrentAnimatingIcon = animatingIcons[currentIconIndex]

    return (
        <Box
            sx={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                minHeight: '75vh',
                p: { xs: 2, sm: 4 },
                bgcolor: 'transparent', // Make background transparent to show gradient/pattern
                color: theme.palette.text.primary,
                borderRadius: theme.shape.borderRadius,
                boxShadow: theme.shadows[6], // Stronger shadow for depth

                mx: 'auto',
                my: { xs: 2, md: 4 },
                textAlign: 'center',
                overflow: 'hidden',
                position: 'relative',
                zIndex: 1, // Ensure content is above background
                // AI-themed background gradient and subtle pattern
                background: `linear-gradient(135deg, ${theme.palette.primary.dark} 0%, ${theme.palette.secondary.dark} 100%)`, // Deep gradient
                '&::before': {
                    // Pseudo-element for circuit pattern
                    content: '""',
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    right: 0,
                    bottom: 0,
                    background: `repeating-linear-gradient(
                        45deg,
                        rgba(255,255,255,0.02) 0px,
                        rgba(255,255,255,0.02) 2px,
                        transparent 2px,
                        transparent 20px
                    ),
                    repeating-linear-gradient(
                        -45deg,
                        rgba(255,255,255,0.02) 0px,
                        rgba(255,255,255,0.02) 2px,
                        transparent 2px,
                        transparent 20px
                    )`,
                    opacity: 0.8, // Make it very subtle
                    zIndex: -1, // Behind the content
                },
            }}
        >
            <Grow in={true} timeout={1000}>
                <Stack
                    spacing={3}
                    alignItems="center"
                    sx={{ width: '100%', zIndex: 2 }}
                >
                    {/* Main Animated Icon */}
                    <Box
                        sx={{
                            position: 'relative',
                            width: 120, // Slightly larger
                            height: 120,
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            borderRadius: '50%', // Make it circular
                            // Glow effect
                            boxShadow: `0 0 15px ${theme.palette.info.main}, 0 0 30px ${theme.palette.info.dark}`,
                            transition: 'box-shadow 0.5s ease-in-out', // Smooth glow transition
                        }}
                    >
                        <Slide
                            direction="down"
                            in={true}
                            key={currentIconIndex}
                            timeout={500}
                            appear={false}
                        >
                            {React.cloneElement(CurrentAnimatingIcon, {
                                sx: {
                                    fontSize: 90, // Icon slightly smaller than box
                                    color: theme.palette.info.light, // Use a bright accent color for the icon itself
                                },
                            })}
                        </Slide>
                    </Box>

                    <Typography
                        variant="h4" // Stronger heading
                        component="h2"
                        sx={{
                            fontWeight: 700, // Bolder
                            color: theme.palette.common.white, // White text against dark background
                            mt: 3, // More top margin
                            textShadow: `0 0 8px ${theme.palette.info.main}`, // Subtle text glow
                        }}
                    >
                        RAIA Initiating Deep Analysis...
                    </Typography>

                    <LinearProgress
                        sx={{
                            width: '80%',
                            height: 10, // Thicker progress bar
                            borderRadius: 5,
                            bgcolor: 'rgba(255,255,255,0.1)', // Lighter, subtle background for bar
                            '& .MuiLinearProgress-bar': {
                                bgcolor: theme.palette.success.light, // Brighter success color
                                transition: 'transform 0.5s linear',
                            },
                        }}
                    />

                    <Box
                        sx={{
                            minHeight: 140, // More height for facts
                            display: 'flex',
                            alignItems: 'center',
                            width: '100%',
                            justifyContent: 'center',
                            py: 2, // Vertical padding
                        }}
                    >
                        <List dense disablePadding sx={{ width: '80%' }}>
                            <Slide
                                direction="up"
                                in={true}
                                key={currentFactIndex}
                                timeout={600} // Slightly longer slide
                                appear={false}
                            >
                                <ListItem sx={{ py: 1 }}>
                                    <ListItemIcon
                                        sx={{
                                            minWidth: 45, // More space for icon
                                            color: currentFact.icon.props.color
                                                ? theme.palette[
                                                      currentFact.icon.props
                                                          .color
                                                  ].light // Use light version of color for better contrast
                                                : theme.palette.info.light, // Fallback to an AI-ish color
                                        }}
                                    >
                                        {React.cloneElement(currentFact.icon, {
                                            sx: { fontSize: 28 },
                                        })}{' '}
                                        {/* Make fact icons larger */}
                                    </ListItemIcon>
                                    <ListItemText
                                        primary={
                                            <Typography
                                                variant="body1"
                                                sx={{
                                                    fontWeight: 500,
                                                    color: theme.palette
                                                        .grey[200], // Lighter grey for facts
                                                    fontStyle: 'italic',
                                                }}
                                            >
                                                {currentFact.text}
                                            </Typography>
                                        }
                                    />
                                </ListItem>
                            </Slide>
                        </List>
                    </Box>

                    <Typography
                        variant="body2"
                        color="text.secondary"
                        sx={{ mt: 3, color: theme.palette.grey[300] }}
                    >
                        Please allow the system to complete its computations.
                    </Typography>
                </Stack>
            </Grow>
        </Box>
    )
}

export default SummaryLoaderPlaceholder
