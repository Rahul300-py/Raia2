// src/components/LLMEvaluationPlatformSection.js
import React from 'react'
import { Box, Typography, Container, Grid, Paper, Stack } from '@mui/material'
import AssessmentOutlinedIcon from '@mui/icons-material/AssessmentOutlined' // Placeholder icon
import ScienceOutlinedIcon from '@mui/icons-material/ScienceOutlined' // Placeholder icon

const LLMEvaluationPlatformSection = () => {
    return (
        <Box
            sx={{
                backgroundColor: '#2d0047',
                py: { xs: 8, md: 12 },
                color: '#fff',
                width: '100%',
            }}
        >
            <Container maxWidth="lg">
                <Typography
                    variant="overline"
                    display="block"
                    color="primary.light"
                    sx={{
                        mb: 2,
                        textTransform: 'uppercase',
                        textAlign: 'center',
                    }}
                >
                    What We Do
                </Typography>
                <Typography
                    variant="h3"
                    component="h2"
                    sx={{ fontWeight: 'bold', mb: 8, textAlign: 'center' }}
                >
                    LLM evaluation platform
                </Typography>
                <Typography
                    variant="body1"
                    sx={{ color: 'primary.light', mb: 8, textAlign: 'center' }}
                >
                    From generating test cases to delivering proof your AI
                    system is ready.
                </Typography>

                <Grid container spacing={5} alignItems="center">
                    <Grid item xs={12} md={6}>
                        <Stack spacing={4}>
                            <Stack
                                direction="row"
                                spacing={3}
                                alignItems="flex-start"
                            >
                                <AssessmentOutlinedIcon
                                    sx={{
                                        fontSize: 40,
                                        color: 'highlight.main',
                                        mt: 0.5,
                                    }}
                                />
                                <Box>
                                    <Typography
                                        variant="h6"
                                        sx={{ fontWeight: 600, mb: 1 }}
                                    >
                                        Automated evaluation
                                    </Typography>
                                    <Typography
                                        variant="body2"
                                        sx={{ color: 'primary.light' }}
                                    >
                                        Measure output accuracy, safety, and
                                        quality. Get a clear, shareable report
                                        showing exactly where AI breaks – down
                                        to each response.
                                    </Typography>
                                </Box>
                            </Stack>
                            <Stack
                                direction="row"
                                spacing={3}
                                alignItems="flex-start"
                            >
                                <ScienceOutlinedIcon
                                    sx={{
                                        fontSize: 40,
                                        color: 'highlight.main',
                                        mt: 0.5,
                                    }}
                                />
                                <Box>
                                    <Typography
                                        variant="h6"
                                        sx={{ fontWeight: 600, mb: 1 }}
                                    >
                                        Synthetic data
                                    </Typography>
                                    <Typography
                                        variant="body2"
                                        sx={{ color: 'primary.light' }}
                                    >
                                        Create realistic, edge-case, and
                                        adversarial inputs tailored to your use
                                        case – from harmless prompts to hostile
                                        attacks.
                                    </Typography>
                                </Box>
                            </Stack>
                        </Stack>
                    </Grid>
                    <Grid item xs={12} md={6}>
                        {/* Placeholder for the dark dashboard screenshot */}
                        <Box
                            sx={{
                                width: '100%',
                                height: { xs: '200px', md: '350px' },
                                backgroundColor: '#1a0026', // Darker purple background for the dashboard mock
                                borderRadius: '15px',
                                display: 'flex',
                                justifyContent: 'center',
                                alignItems: 'center',
                                overflow: 'hidden',
                                position: 'relative',
                                boxShadow: '0 10px 40px rgba(0, 0, 0, 0.3)',
                            }}
                        >
                            {/* Simplified mock dashboard elements */}
                            <Box
                                sx={{
                                    position: 'absolute',
                                    top: 20,
                                    left: 20,
                                    right: 20,
                                    bottom: 20,
                                    backgroundColor: '#3a0058',
                                    borderRadius: '10px',
                                    p: 2,
                                    display: 'flex',
                                    flexDirection: 'column',
                                    gap: 2,
                                }}
                            >
                                <Stack
                                    direction="row"
                                    justifyContent="space-between"
                                    alignItems="center"
                                >
                                    <Typography
                                        variant="body2"
                                        sx={{ color: 'primary.light' }}
                                    >
                                        Metrics
                                    </Typography>
                                    <Typography
                                        variant="body2"
                                        sx={{ color: 'primary.light' }}
                                    >
                                        Tests
                                    </Typography>
                                </Stack>
                                <Grid container spacing={1}>
                                    <Grid item xs={6}>
                                        <Box
                                            sx={{
                                                bgcolor: 'secondary.main',
                                                p: 1,
                                                borderRadius: '5px',
                                            }}
                                        >
                                            <Typography
                                                variant="caption"
                                                sx={{ color: 'white' }}
                                            >
                                                Safety
                                            </Typography>
                                        </Box>
                                    </Grid>
                                    <Grid item xs={6}>
                                        <Box
                                            sx={{
                                                bgcolor: 'secondary.main',
                                                p: 1,
                                                borderRadius: '5px',
                                            }}
                                        >
                                            <Typography
                                                variant="caption"
                                                sx={{ color: 'white' }}
                                            >
                                                Tone
                                            </Typography>
                                        </Box>
                                    </Grid>
                                </Grid>
                                <Box
                                    sx={{
                                        flexGrow: 1,
                                        display: 'grid',
                                        gridTemplateColumns: '1fr 1fr',
                                        gap: '8px',
                                    }}
                                >
                                    <Box
                                        sx={{
                                            bgcolor: 'secondary.dark',
                                            borderRadius: '5px',
                                            height: '100%',
                                        }}
                                    />
                                    <Box
                                        sx={{
                                            bgcolor: 'secondary.dark',
                                            borderRadius: '5px',
                                            height: '100%',
                                        }}
                                    />
                                </Box>
                                <Box
                                    sx={{
                                        bgcolor: 'secondary.dark',
                                        height: '30px',
                                        borderRadius: '5px',
                                    }}
                                />
                            </Box>
                        </Box>
                    </Grid>
                </Grid>
            </Container>
        </Box>
    )
}

export default LLMEvaluationPlatformSection
