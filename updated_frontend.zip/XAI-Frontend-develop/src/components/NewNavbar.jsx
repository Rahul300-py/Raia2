import React, { useState } from 'react'
import {
    AppBar,
    Toolbar,
    Box,
    Typography,
    Button,
    IconButton,
    Stack,
    Menu,
    MenuItem,
    Link,
} from '@mui/material'
import SearchIcon from '@mui/icons-material/Search'
import GitHubIcon from '@mui/icons-material/GitHub'
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown'

const logoSrc = '/logo-nav.png'

const navItems = [
    {
        name: 'Product',
        items: ['Product Item 1', 'Product Item 2'],
    },
    {
        name: 'Pricing',
        items: ['Pricing Tier 1', 'Pricing Tier 2'],
    },
    {
        name: 'Resources',
        items: ['Resource A', 'Resource B'],
    },
]

const NewNavbar = () => {
    const [anchorEl, setAnchorEl] = useState(null)
    const [menuIndex, setMenuIndex] = useState(null)

    const handleMenuOpen = (e, index) => {
        setAnchorEl(e.currentTarget)
        setMenuIndex(index)
    }

    const handleMenuClose = () => {
        setAnchorEl(null)
        setMenuIndex(null)
    }

    return (
        <>
            {/* Top Bar Message */}
            {/* <Box
                sx={{
                    width: '100%',
                    backgroundColor: '#000',
                    color: '#fff',
                    textAlign: 'center',
                    py: 1.2,
                    fontSize: '0.85rem',
                    zIndex: 1200,
                }}
            >
                Achieve confidence in your AI. Ensure your models are
                interpretable and unbiased.
                <Link href="#" sx={{ color: '#ccc', ml: 1 }} underline="hover">
                    Learn more &gt;
                </Link>
            </Box> */}

            <AppBar
                position="sticky"
                sx={{
                    backgroundColor: '#0d0d2b',
                    color: '#fff',
                    boxShadow: 'none',
                    borderRadius: 0,
                    px: { xs: 2, sm: 4 },
                    zIndex: 1100,
                }}
            >
                <Toolbar
                    sx={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        py: 1.5,
                        maxWidth: '1300px',
                        mx: 'auto',
                        width: '100%',
                    }}
                >
                    {/* Logo */}
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <Box
                            component="img"
                            src={logoSrc}
                            alt="Logo"
                            sx={{ height: 32, mr: 1 }}
                        />
                    </Box>

                    {/* CTA Buttons */}
                    <Stack direction="row" spacing={4} alignItems="center">
                        {navItems.map((item, index) => (
                            <Box
                                key={item.name}
                                onMouseEnter={(e) => handleMenuOpen(e, index)}
                                onMouseLeave={handleMenuClose}
                                sx={{
                                    fontSize: '0.95rem',
                                    fontWeight: 600,
                                    cursor: 'pointer',
                                    display: 'flex',
                                    alignItems: 'center',
                                    color: 'white',
                                }}
                            >
                                {item.name}
                                <KeyboardArrowDownIcon
                                    sx={{ fontSize: '1rem', ml: 0.5 }}
                                />
                                <Menu
                                    anchorEl={anchorEl}
                                    open={menuIndex === index}
                                    onClose={handleMenuClose}
                                    PaperProps={{
                                        onMouseEnter: () => setMenuIndex(index),
                                        onMouseLeave: handleMenuClose,
                                        sx: {
                                            mt: 1,
                                            borderRadius: '3px',
                                            boxShadow: 6,
                                            backgroundColor: '#fff',
                                            minWidth: 200,
                                        },
                                    }}
                                    anchorOrigin={{
                                        vertical: 'bottom',
                                        horizontal: 'left',
                                    }}
                                    transformOrigin={{
                                        vertical: 'top',
                                        horizontal: 'left',
                                    }}
                                >
                                    {item.items.map((menuItem, i) => (
                                        <MenuItem
                                            key={i}
                                            onClick={handleMenuClose}
                                            sx={{ fontSize: '0.9rem' }}
                                        >
                                            {menuItem}
                                        </MenuItem>
                                    ))}
                                </Menu>
                            </Box>
                        ))}

                        {/* <Link href="#" color="inherit" underline="hover">
                            Docs
                        </Link> */}
                        <Button
                            color="inherit"
                            sx={{ textTransform: 'none' }}
                            href="/login"
                        >
                            Log in
                        </Button>
                        <Button
                            variant="contained"
                            sx={{
                                backgroundColor: '#fff',
                                color: '#0d0d2b',
                                textTransform: 'none',
                                fontWeight: 600,
                                px: 3,
                                py: 1,
                                borderRadius: '999px',
                            }}
                            href="/signup"
                        >
                            Sign up
                        </Button>
                        <IconButton sx={{ color: 'white' }}>
                            <SearchIcon />
                        </IconButton>
                    </Stack>
                </Toolbar>
            </AppBar>
        </>
    )
}

export default NewNavbar
