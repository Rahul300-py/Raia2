import React, { useState } from 'react'
import {
    Box,
    Typography,
    TextField,
    Slider,
    Button,
    Paper,
    Grid,
} from '@mui/material'

const PredictionPanel = () => {
    const [featureA, setFeatureA] = useState('')
    const [featureB, setFeatureB] = useState(0.5)
    const [featureC, setFeatureC] = useState('')
    const [featureD, setFeatureD] = useState('')

    return (
        <Box sx={{ display: 'flex', gap: 4, px: 6, py: 4 }}>
            {/* Left: Instance Controls */}
            <Box sx={{ width: '30%' }}>
                <Typography variant="h6" fontWeight={600} gutterBottom>
                    Instance Controls
                </Typography>

                <TextField
                    fullWidth
                    label="Instance ID"
                    variant="outlined"
                    size="small"
                    sx={{ mb: 2 }}
                />
                <TextField
                    fullWidth
                    label="Feature A"
                    variant="outlined"
                    size="small"
                    value={featureA}
                    onChange={(e) => setFeatureA(e.target.value)}
                    sx={{ mb: 2 }}
                />
                <Typography variant="body2" gutterBottom>
                    Feature B
                </Typography>
                <Slider
                    value={featureB}
                    min={0}
                    max={1}
                    step={0.01}
                    onChange={(e, newValue) => setFeatureB(newValue)}
                    sx={{ mb: 2 }}
                />
                <TextField
                    fullWidth
                    label="Feature C"
                    variant="outlined"
                    size="small"
                    value={featureC}
                    onChange={(e) => setFeatureC(e.target.value)}
                    sx={{ mb: 2 }}
                />
                <TextField
                    fullWidth
                    label="Feature D"
                    variant="outlined"
                    size="small"
                    value={featureD}
                    onChange={(e) => setFeatureD(e.target.value)}
                    sx={{ mb: 3 }}
                />
                <TextField
                    fullWidth
                    label="Feature D"
                    variant="outlined"
                    size="small"
                    value={featureD}
                    onChange={(e) => setFeatureD(e.target.value)}
                    sx={{ mb: 3 }}
                />
                <TextField
                    fullWidth
                    label="Feature E"
                    variant="outlined"
                    size="small"
                    value={featureD}
                    onChange={(e) => setFeatureD(e.target.value)}
                    sx={{ mb: 3 }}
                />
                <TextField
                    fullWidth
                    label="Feature F"
                    variant="outlined"
                    size="small"
                    value={featureD}
                    onChange={(e) => setFeatureD(e.target.value)}
                    sx={{ mb: 3 }}
                />

                <Button variant="contained" color="primary" fullWidth>
                    Suggest Changes
                </Button>
            </Box>

            {/* Right: Prediction Updates */}
            <Box sx={{ flexGrow: 1 }}>
                <Typography variant="h6" fontWeight={600} gutterBottom>
                    Prediction Updates
                </Typography>

                <Grid container spacing={2} sx={{ mb: 3 }}>
                    <Grid item xs={6}>
                        <Paper sx={{ p: 2, bgcolor: '#f5f7fa' }}>
                            <Typography variant="body2" color="textSecondary">
                                Current Prediction
                            </Typography>
                            <Typography variant="h6" fontWeight={600}>
                                Positive
                            </Typography>
                        </Paper>
                    </Grid>
                    <Grid item xs={6}>
                        <Paper sx={{ p: 2, bgcolor: '#f5f7fa' }}>
                            <Typography variant="body2" color="textSecondary">
                                Confidence
                            </Typography>
                            <Typography variant="h6" fontWeight={600}>
                                85%
                            </Typography>
                        </Paper>
                    </Grid>
                </Grid>

                <Typography variant="subtitle1" fontWeight={600} gutterBottom>
                    Suggested Changes
                </Typography>

                {[1, 2].map((item) => (
                    <Paper
                        key={item}
                        sx={{
                            height: 140,
                            mb: 2,
                            backgroundImage: `url('https://source.unsplash.com/random/800x60${item}')`,
                            backgroundSize: 'cover',
                            backgroundPosition: 'center',
                            position: 'relative',
                            display: 'flex',
                            alignItems: 'flex-end',
                            p: 2,
                            color: '#fff',
                            borderRadius: 2,
                            overflow: 'hidden',
                        }}
                    >
                        <Box>
                            <Typography variant="body1" fontWeight={600}>
                                {item === 1
                                    ? 'Change Feature A to 0.9'
                                    : 'Change Feature B to 0.2'}
                            </Typography>
                            <Typography variant="body2">
                                New Prediction: Negative (Confidence:{' '}
                                {item === 1 ? '70%' : '65%'})
                            </Typography>
                        </Box>
                    </Paper>
                ))}

                <Button variant="outlined" sx={{ mt: 1 }}>
                    Explain These Changes (LLM)
                </Button>
            </Box>
        </Box>
    )
}

export default PredictionPanel
