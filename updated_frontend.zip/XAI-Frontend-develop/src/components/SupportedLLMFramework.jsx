import React from 'react'
import {
    Box,
    Container,
    Grid,
    Paper,
    Typography,
    List,
    ListItem,
    ListItemIcon,
    ListItemText,
} from '@mui/material'
import CheckCircleIcon from '@mui/icons-material/CheckCircle'
import HubIcon from '@mui/icons-material/Hub'
import StorageIcon from '@mui/icons-material/Storage'
import EmojiEventsIcon from '@mui/icons-material/EmojiEvents'
import AutoAwesomeIcon from '@mui/icons-material/AutoAwesome'

const integrationSections = [
    {
        title: 'LangChain Integration',
        icon: <HubIcon />,
        description: 'Full support for LangChain-based applications',
        items: [
            [
                'Chain Execution Monitoring',
                'Track chain execution and debug issues',
            ],
            ['Memory System Evaluation', 'Assess memory system performance'],
            ['Agent Behavior Analysis', 'Analyze agent decision patterns'],
            [
                'Tool Usage Optimization',
                'Measure and optimize tool performance',
            ],
        ],
    },
    {
        title: 'LlamaIndex Support',
        icon: <StorageIcon />,
        description: 'Native integration with LlamaIndex workflows',
        items: [
            [
                'Index Structure Analysis',
                'Evaluate index organization and efficiency',
            ],
            ['Query Engine Evaluation', 'Assess query execution performance'],
            [
                'Retriever Performance Metrics',
                'Measure retriever accuracy and speed',
            ],
            [
                'Response Synthesizer Assessment',
                'Review response generation quality',
            ],
        ],
    },
    {
        title: 'Hugging Face Ecosystem',
        icon: <EmojiEventsIcon />,
        description: 'Seamless integration with HF models and datasets',
        items: [
            ['Model Card Generation', 'Auto-generate model documentation'],
            [
                'Dataset Quality Assessment',
                'Evaluate dataset completeness and diversity',
            ],
            [
                'Tokenizer Efficiency Analysis',
                'Measure tokenization accuracy and speed',
            ],
            ['Fine-tuning Evaluation', 'Assess fine-tuning effectiveness'],
        ],
    },
    // {
    //     title: 'Custom Framework Support',
    //     icon: <AutoAwesomeIcon />,
    //     description: 'Flexible APIs for any LLM/RAG implementation',
    //     items: [
    //         ['RESTful API Endpoints', 'Expose custom metrics through APIs'],
    //         ['Python SDK with Decorators', 'Simplified metric instrumentation'],
    //         ['Real-time Streaming Evaluation', 'Evaluate model behavior live'],
    //         [
    //             'Custom Metric Definitions',
    //             'Define and register your own metrics',
    //         ],
    //     ],
    // },
]

const SupportedLLMFramework = () => {
    return (
        <Box
            sx={{
                color: '#fff',
                py: 8,
            }}
        >
            <Container maxWidth="lg">
                <Typography
                    variant="subtitle1"
                    sx={{
                        color: 'rgba(0, 0, 0, 0.7)',
                        mb: 5,
                        textAlign: 'left',
                        maxWidth: '600px',
                    }}
                >
                    🔌 Supported LLM & RAG Frameworks
                </Typography>

                {/*  Large Language Model Evaluation */}
                <Grid container spacing={3}>
                    {integrationSections.map((section, idx) => (
                        <Grid item xs={12} md={4} key={idx}>
                            <Paper
                                elevation={0}
                                sx={{
                                    border: '1px solid rgb(16, 17, 17)',
                                    borderRadius: '16px',
                                    p: 3,
                                    height: '100%',
                                    maxWidth: '360px',
                                }}
                            >
                                <Box
                                    sx={{
                                        display: 'flex',
                                        alignItems: 'center',
                                        gap: 1,
                                        mb: 2,
                                    }}
                                >
                                    <Box
                                        sx={{
                                            background:
                                                'linear-gradient(135deg, #8B5CF6, #6366F1)',
                                            borderRadius: '10px',
                                            p: 1,
                                            display: 'flex',
                                        }}
                                    >
                                        {section.icon}
                                    </Box>
                                    <Typography
                                        variant="subtitle1"
                                        sx={{ fontWeight: 700 }}
                                    >
                                        {section.title}
                                    </Typography>
                                </Box>
                                <Typography
                                    variant="body2"
                                    sx={{
                                        mb: 2,
                                    }}
                                >
                                    {section.description}
                                </Typography>
                                <List dense>
                                    {section.items.map(([label, text], i) => (
                                        <ListItem key={i} disableGutters>
                                            <ListItemIcon
                                                sx={{
                                                    minWidth: '30px',
                                                }}
                                            >
                                                <CheckCircleIcon fontSize="small" />
                                            </ListItemIcon>
                                            <ListItemText
                                                primary={
                                                    <Box component="span">
                                                        <Typography
                                                            component="span"
                                                            sx={{
                                                                fontWeight: 600,
                                                            }}
                                                        >
                                                            {label}:{' '}
                                                        </Typography>
                                                        <Typography
                                                            component="span"
                                                            sx={{}}
                                                        >
                                                            {text}
                                                        </Typography>
                                                    </Box>
                                                }
                                            />
                                        </ListItem>
                                    ))}
                                </List>
                            </Paper>
                        </Grid>
                    ))}
                </Grid>

                {/* RAG System Evaluation */}
            </Container>
        </Box>
    )
}

export default SupportedLLMFramework
