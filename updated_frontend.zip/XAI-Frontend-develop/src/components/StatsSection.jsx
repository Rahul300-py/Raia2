// src/components/StatsSection.js
import React from 'react'
import { Box, Typography, Container, Stack } from '@mui/material'

const StatsSection = () => {
    return (
        <Container
            maxWidth="lg"
            sx={{ textAlign: 'center', py: { xs: 8, md: 10 } }}
        >
            <Typography
                variant="overline"
                display="block"
                color="text.secondary"
                sx={{ mb: 2, textTransform: 'uppercase' }}
            >
                Open Source
            </Typography>
            <Typography
                variant="h3"
                component="h2"
                sx={{ fontWeight: 'bold', mb: 8 }}
            >
                Powered by the leading{' '}
                <Box component="span" sx={{ color: 'secondary.main' }}>
                    open-source tool
                </Box>
            </Typography>

            <Stack
                direction={{ xs: 'column', md: 'row' }}
                spacing={{ xs: 5, md: 10 }}
                justifyContent="center"
                alignItems="center"
            >
                <Box>
                    <Typography
                        variant="h3"
                        sx={{
                            fontWeight: 'bold',
                            color: 'text.highlight',
                        }}
                    >
                        6000+
                    </Typography>
                    <Typography
                        variant="body1"
                        sx={{ color: 'text.highlight' }}
                    >
                        GitHub stars
                    </Typography>
                </Box>
                <Box>
                    <Typography
                        variant="h3"
                        sx={{ fontWeight: 'bold', color: 'text.highlight' }}
                    >
                        25m+
                    </Typography>
                    <Typography
                        variant="body1"
                        sx={{ color: 'text.secondary' }}
                    >
                        Downloads
                    </Typography>
                </Box>
                <Box>
                    <Typography
                        variant="h3"
                        sx={{ fontWeight: 'bold', color: 'text.highlight' }}
                    >
                        3000+
                    </Typography>
                    <Typography
                        variant="body1"
                        sx={{ color: 'text.secondary' }}
                    >
                        Community members
                    </Typography>
                </Box>
            </Stack>
        </Container>
    )
}

export default StatsSection
