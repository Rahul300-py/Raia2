// src/components/UseCasesSection.js
import React from 'react'
import { Box, Typography, Container, Grid, Stack, Link } from '@mui/material'
import ArrowForwardIcon from '@mui/icons-material/ArrowForward'
import SecurityOutlinedIcon from '@mui/icons-material/SecurityOutlined' // Placeholder icon
import QuestionAnswerOutlinedIcon from '@mui/icons-material/QuestionAnswerOutlined' // Placeholder icon
import GroupsOutlinedIcon from '@mui/icons-material/GroupsOutlined' // Placeholder icon
import BarChartOutlinedIcon from '@mui/icons-material/BarChartOutlined' // Placeholder icon

const UseCasesSection = () => {
    const useCases = [
        {
            icon: <SecurityOutlinedIcon />,
            title: 'Adversarial testing',
            description:
                'Attack your AI system - before others do. Probe for PII leaks, jailbreaks and harmful content.',
        },
        {
            icon: <QuestionAnswerOutlinedIcon />,
            title: 'RAG evaluation',
            description:
                'Prevent hallucinations and test retrieval accuracy in RAG pipelines and chatbots.',
        },
        {
            icon: <GroupsOutlinedIcon />,
            title: 'AI agents',
            description:
                'Go beyond single responses - validate multi-step workflows, reasoning, and tool use.',
        },
        {
            icon: <BarChartOutlinedIcon />,
            title: 'Predictive systems',
            description:
                'Stay on top of classifiers, summarizers, recommenders, and traditional ML models.',
        },
    ]

    return (
        <Box
            sx={{
                backgroundColor: 'background.default',
                py: { xs: 8, md: 12 },
                width: '100%',
            }}
        >
            <Container maxWidth="lg" sx={{ textAlign: 'center' }}>
                <Typography
                    variant="overline"
                    display="block"
                    color="text.secondary"
                    sx={{ mb: 2, textTransform: 'uppercase' }}
                >
                    Use Cases
                </Typography>
                <Typography
                    variant="h3"
                    component="h2"
                    sx={{ fontWeight: 'bold', mb: 8 }}
                >
                    What do you want to test first?
                </Typography>
                <Typography
                    variant="body1"
                    sx={{ color: 'text.secondary', mb: 8 }}
                >
                    Built for what you are building.
                </Typography>

                <Grid
                    container
                    spacing={4}
                    sx={{
                        display: 'flex',
                        flexDirection: 'row',
                        flexWrap: 'wrap',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                    }}
                >
                    {useCases.map((useCase, index) => (
                        <Grid item xs={12} sm={6} md={3} key={index} flex={1}>
                            <Stack
                                spacing={2}
                                sx={{
                                    p: 3,
                                    border: '1px solid #eee',
                                    borderRadius: '10px',
                                    height: '100%',
                                    alignItems: 'flex-start',
                                    textAlign: 'left',
                                }}
                            >
                                <Box
                                    sx={{
                                        color: 'highlight.main',
                                        fontSize: 40,
                                    }}
                                >
                                    {useCase.icon}
                                </Box>
                                <Typography
                                    variant="h6"
                                    sx={{ fontWeight: 600 }}
                                >
                                    {useCase.title}
                                </Typography>
                                <Typography
                                    variant="body2"
                                    sx={{
                                        color: 'text.secondary',
                                        flexGrow: 1,
                                    }}
                                >
                                    {useCase.description}
                                </Typography>
                                <Link
                                    href="#"
                                    sx={{
                                        display: 'inline-flex',
                                        alignItems: 'center',
                                        color: 'highlight.main',
                                        fontWeight: 'bold',
                                    }}
                                >
                                    Learn more{' '}
                                    <ArrowForwardIcon
                                        sx={{
                                            ml: 0.5,
                                            fontSize: '1em',
                                            color: 'highlight.main',
                                        }}
                                    />
                                </Link>
                            </Stack>
                        </Grid>
                    ))}
                </Grid>
            </Container>
        </Box>
    )
}

export default UseCasesSection
