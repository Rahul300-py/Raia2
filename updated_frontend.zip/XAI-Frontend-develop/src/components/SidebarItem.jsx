import {
    ListItem,
    ListItemButton,
    ListItemIcon,
    ListItemText,
    Tooltip,
} from '@mui/material'

const SidebarItem = ({ text, icon, collapsed, onClick }) => {
    const content = (
        <ListItemButton
            onClick={onClick}
            sx={{
                justifyContent: collapsed ? 'center' : 'flex-start',
                px: 2,
            }}
        >
            <ListItemIcon
                sx={{
                    color: '#fff',
                    minWidth: 0,
                    mr: collapsed ? 0 : 2,
                    justifyContent: 'center',
                }}
            >
                {icon}
            </ListItemIcon>
            {!collapsed && <ListItemText primary={text} />}
        </ListItemButton>
    )

    return (
        <ListItem disablePadding>
            {collapsed ? (
                <Tooltip title={text} placement="right" arrow>
                    {content}
                </Tooltip>
            ) : (
                content
            )}
        </ListItem>
    )
}

export default SidebarItem
