from sqlalchemy import Column, String, JSON, Text, DateTime, Integer, func
from shared_migrations.models.base import Base

class AnalysisResult(Base):

    __tablename__ = "analysis_results"

    id = Column(Integer, primary_key=True)
    analysis_id = Column(String, unique=True, index=True) # Frontend Fetches Processed Result by analysis_id
    user_id = Column(String, nullable=True) # drift, regression, classification, etc.
    input_hash = Column(String, nullable=True) # hash of uploaded data
    json_result = Column(JSON, nullable=True) #  structured JSON
    html_result = Column(Text, nullable=True) # Optional
    created_at = Column(DateTime(timezone=True), default=func.now())
