import requests
import mimetypes
import os
from fastapi import APIRouter, HTTPException, Response
from dotenv import load_dotenv
load_dotenv()  # Load environment variables from .env file

def upload_file_to_api(api_url: str, jwt_token: str, file_path: str, user_id: int, tenant_id: int) -> str:
    headers = {
        "Authorization": f"Bearer {jwt_token}"
    }

    content_type, _ = mimetypes.guess_type(file_path)

    files = {
        'files': (file_path.split("/")[-1], open(file_path, 'rb'), content_type or 'application/csv')
    }

    data = {
        'user_id': str(user_id),
        'tenant_id': str(tenant_id)
    }

    try:
        response = requests.post(api_url, headers=headers, files=files, data=data)

        if response.status_code == 200:
            return "File uploaded successfully."
        else:
            return f"Upload failed. Status code: {response.status_code}. Details: {response.text}"

    except Exception as e:
        return f"An error occurred: {str(e)}"


# Example call
api_url = "http://xailoadbalancer-579761463.ap-south-1.elb.amazonaws.com:8000/files_upload/"
jwt_token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJzaWx2eUBleGFtcGxlLmNvbSIsImV4cCI6MTc1MDE0NTg1MH0.mGd4iv3PXRJeDP9TRD1bxnKW558LkI6I389RGvKUqlo"  # Replace with actual token
file_path = "tests/file.json"  # Replace with actual file
user_id = 6
tenant_id = 1

res = upload_file_to_api(api_url, jwt_token, file_path, user_id, tenant_id)
print(res)



@router.get("/")
def download_single_file_if_only_one():

    # Get env vars at request time (so .env is definitely loaded)
    AWS_ACCESS_KEY_ID = os.getenv("AWS_ACCESS_KEY_ID")
    AWS_SECRET_ACCESS_KEY = os.getenv("AWS_SECRET_ACCESS_KEY")
    AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
    S3_BUCKET = os.getenv("S3_BUCKET")
    FOLDER_PREFIX = "files/"

    # # Debug print
    print(f"AWS_ACCESS_KEY_ID: {AWS_ACCESS_KEY_ID}")
    print(f"AWS_SECRET_ACCESS_KEY: {AWS_SECRET_ACCESS_KEY}")
    print(f"AWS_REGION: {AWS_REGION}")
    print(f"S3_BUCKET: {S3_BUCKET}")
    


    if not S3_BUCKET:
        raise HTTPException(status_code=500, detail="S3_BUCKET is not set")

    s3_client = get_s3_client()

    try:
        response = s3_client.list_objects_v2(Bucket=S3_BUCKET, Prefix=FOLDER_PREFIX)

        if "Contents" not in response:
            raise HTTPException(status_code=404, detail="No files found in S3 folder.")

        files = [obj["Key"] for obj in response["Contents"] if not obj["Key"].endswith("/")]

        if not files:
            raise HTTPException(status_code=404, detail="No files found in S3 folder.")

        if len(files) > 1:
            return {
                "message": "Multiple files found",
                "files": [key[len(FOLDER_PREFIX):] for key in files]
            }

        key = files[0]
        file_obj = s3_client.get_object(Bucket=S3_BUCKET, Key=key)
        file_body = file_obj["Body"].read()
        content_type = file_obj.get("ContentType", "application/octet-stream")

        return Response(content=file_body, media_type=content_type)

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing request: {str(e)}")
