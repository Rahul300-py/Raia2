from dotenv import load_dotenv
from botocore.exceptions import BotoCoreError, ClientError, NoCredentialsError
from io import BytesIO
import os
import boto3
load_dotenv()
from fastapi import HTTPException
from shared_migrations.models.tenant import Tenant
from services.API.app.database.connections import get_db
from sqlalchemy.orm import Session
from fastapi import Depends, status

AWS_ACCESS_KEY_ID = os.getenv("AWS_ACCESS_KEY_ID")
AWS_SECRET_ACCESS_KEY = os.getenv("AWS_SECRET_ACCESS_KEY")
AWS_REGION = os.getenv("AWS_REGION")
S3_BUCKET = os.getenv("S3_BUCKET")

s3_client = boto3.client(
    "s3",
    region_name=AWS_REGION,
    aws_access_key_id=AWS_ACCESS_KEY_ID,
    aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
)

FILE_MODEL_DOWNLOAD_API = "http://xailoadbalancer-579761463.ap-south-1.elb.amazonaws.com/api/files_download"
# FILE_MODEL_DOWNLOAD_API = "http://localhost:8000/api/files_download"

ALLOWED_CONTENT_TYPES = {
    "text/plain",        # .txt
    "text/csv",          # .csv
    "application/json",  # .json
    "application/vnd.ms-excel"  # .csv (Excel style)
}

ALLOWED_MODEL_TYPES = {
    "application/octet-stream",  # Often for pickle
    "application/onnx",          # ONNX
    "application/xml",           # PMML
}

ALLOWED_MODEL_EXTENSIONS = {
    ".pkl", ".joblib", ".onnx", ".xml"
}


ALLOWED_ANALYSIS_TYPES = {
    "Data Drift": "datadrift",
    "Fairness":"fairness",
    "Classification":"classification",
    "Regression":"regression"

}

def check_analysis(analysis_type):

    analysis = ""
    for key,val in ALLOWED_ANALYSIS_TYPES.items():
        if analysis_type in key:
            analysis=val
        else:
            continue
    return analysis

def is_valid_model_file(filename: str, content_type: str) -> bool:
    ext = os.path.splitext(filename)[1].lower()
    return content_type in ALLOWED_MODEL_TYPES and ext in ALLOWED_MODEL_EXTENSIONS


def upload_to_s3(username: str, analysis:str, file_content: bytes, filename: str, content_type: str, tenant_id, db: Session):
    try:
        tenant_data = db.query(Tenant).filter_by(id=tenant_id).first()
        if not tenant_data:
            raise HTTPException(status_code=404, detail="Tenant not found")
        
        tenant_name = tenant_data.name
        ext = os.path.splitext(filename)[1].lower()

        if content_type in ALLOWED_CONTENT_TYPES:
            base_prefix = f"{tenant_name}/{username}/{analysis}/files/"
        elif is_valid_model_file(filename, content_type):
            base_prefix = f"{tenant_name}/{username}/{analysis}/models/"
        else:
            raise HTTPException(
                status_code=400,
                detail=f"Unsupported content type or extension: type={content_type}, ext={ext}"
            )

        s3_key = f"{base_prefix}{filename}"
        print(f"Uploading to S3 key: {s3_key}")

        s3_client.upload_fileobj(
            Fileobj=BytesIO(file_content),
            Bucket=S3_BUCKET,
            Key=s3_key,
            ExtraArgs={'ContentType': content_type}
        )

        file_url = f"https://{S3_BUCKET}.s3.{AWS_REGION}.amazonaws.com/{s3_key}"
        return file_url

    except (BotoCoreError, NoCredentialsError, ClientError) as e:
        raise HTTPException(status_code=500, detail=f"S3 Upload Error: {str(e)}")

# file download 
def get_s3_client():
    return boto3.client(
        "s3",
        aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
        aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY"),
        region_name=os.getenv("AWS_REGION", "us-east-1")
    )

def get_json_file_from_s3(bucket_name: str, file_key: str):
    s3_client = get_s3_client()
    try:
        response = s3_client.get_object(Bucket=bucket_name, Key=file_key)
        json_data = response['Body'].read().decode('utf-8')
        return json_data
    except ClientError as e:
        raise HTTPException(status_code=404, detail=f"File not found or S3 error: {str(e)}")
