from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from shared.auth import get_current_user
from sqlalchemy import create_engine
from sqlalchemy.exc import SQLAlchemyError
from pymongo import MongoClient
from pymongo.errors import PyMongoError
import oracledb
import urllib.parse

router = APIRouter(prefix="/api", tags=["API"])

class RequestData(BaseModel):
    database_type : str  # Mysql, Postgress, Mongo DB, Oracle, SQL Server, JDBC
    cloud_provider : str
    database_name : str
    host : str
    port : int
    username : str
    password : str
    database_region : str

@router.post("/test-database-connection")
def test_database_connection(request: RequestData, current_user = Depends(get_current_user)):
    db_type = request.database_type.strip().lower()

    try:
        if db_type == "mysql":
            url = f"mysql+pymysql://{request.username}:{request.password}@{request.host}:{request.port}/{request.database_name}"
            engine = create_engine(url)
            with engine.connect():
                return {"status": "success", "message": "MySQL database connection successful."}

        elif db_type in ("postgres", "postgresql"):
            url = f"postgresql://{request.username}:{request.password}@{request.host}:{request.port}/{request.database_name}"
            engine = create_engine(url)
            with engine.connect():
                return {"status": "success", "message": "PostgreSQL database connection successful."}

        elif db_type in ("mongo", "mongodb"):
            uri = f"mongodb://{request.username}:{request.password}@{request.host}:{request.port}"
            client = MongoClient(uri, serverSelectionTimeoutMS=5000)
            client.server_info()
            return {"status": "success", "message": "MongoDB connection successful."}

        elif db_type == "oracle":
            dsn = f"{request.host}:{request.port}/{request.database_name}"
            conn = oracledb.connect(user=request.username, password=request.password, dsn=dsn)
            conn.close()
            return {"status": "success", "message": "Oracle DB connection successful."}

        elif db_type in ("sqlserver", "mssql"):
            quoted = urllib.parse.quote_plus(
                f"DRIVER={{ODBC Driver 17 for SQL Server}};"
                f"SERVER={request.host},{request.port};"
                f"DATABASE={request.database_name};"
                f"UID={request.username};"
                f"PWD={request.password}"
            )
            url = f"mssql+pyodbc:///?odbc_connect={quoted}"
            engine = create_engine(url)
            with engine.connect():
                return {"status": "success", "message": "SQL Server connection successful."}

        elif db_type == "jdbc":
            url = request.host  # Full JDBC-style connection string must be passed here
            engine = create_engine(url)
            with engine.connect():
                return {"status": "success", "message": "Generic JDBC connection successful via SQLAlchemy."}

        else:
            raise HTTPException(status_code=400, detail="Unsupported or unknown database type.")

    except (SQLAlchemyError, PyMongoError, oracledb.DatabaseError, Exception) as e:
        raise HTTPException(status_code=500, detail=f"Database connection failed: {str(e)}")
