from fastapi import APIRouter, Depends
from services.API.app.models import Tenant
from services.API.app.schemas.tenant import CreateTenant, ReadTenant
from sqlalchemy.orm import Session
from services.API.app.database.connections import get_db


router = APIRouter(prefix="/api", tags=["API"])

@router.post("/tenant", response_model=ReadTenant)
def create_tenant(tenant:CreateTenant, db: Session = Depends(get_db)):

    db_tenant = Tenant(**tenant.dict())
    db.add(db_tenant)
    db.commit()
    db.refresh(db_tenant)
    return db_tenant