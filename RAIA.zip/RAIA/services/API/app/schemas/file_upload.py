from pydantic import BaseModel


class FileStorage(BaseModel):

    pass