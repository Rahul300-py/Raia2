from pydantic import BaseModel
from typing import List


class AssignRolesRequest(BaseModel):
    user_id: int
    role_ids: List[int]