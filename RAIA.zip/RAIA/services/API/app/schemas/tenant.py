from pydantic import BaseModel



class CreateTenant(BaseModel):
    name:str  
    email:str 
    mobile:int
    domain:str


class ReadTenant(BaseModel):
    id: int
    name:str  
    email:str 
    mobile:int
    domain:str

    class Config:
        from_attributes = True
