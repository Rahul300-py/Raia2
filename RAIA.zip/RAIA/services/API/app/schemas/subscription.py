from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class CreateSubscription(BaseModel):
    tenant_id: int
    plan_id: int
    start_date: datetime
    end_date: datetime
    payment_status:str
    status:str

class ReadSubscription(BaseModel):
    id: int
    tenant_id: int
    plan_id: int
    start_date: datetime
    end_date: datetime
    payment_status:str
    status:str

    class Config:
        from_attributes = True
