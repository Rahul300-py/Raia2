from fastapi import FastAPI

from services.API.app.routers import plan
from services.API.app.routers import subscription
from services.API.app.routers import users
from services.API.app.routers import tenant
from services.API.app.routers import auth
from services.API.app.routers import file_upload
from services.API.app.routers import model_upload
from services.API.app.routers import download_files
from services.API.app.routers import addrole
from services.API.app.routers import assign_role_to_users as addrole
from services.API.app.routers import database_connection_test

app = FastAPI(
    title="Welcome to API Service",
    description="Service for managing API requests.",
    version="3.1.0",
    docs_url="/api/docs",
    openapi_url="/api/openapi.json",
    redoc_url="/api/redocs"
)

from fastapi.middleware.cors import CORSMiddleware

# Allow CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # You can replace "*" with ["http://localhost:3000"] or your frontend URL for security
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/api/health", status_code=200)
def health_check():
    return {"status": "API-healthy"}

app.include_router(plan.router)
app.include_router(subscription.router)
app.include_router(users.router)
app.include_router(tenant.router)
app.include_router(auth.router)
app.include_router(file_upload.router)
app.include_router(download_files.router)
app.include_router(addrole.router)
app.include_router(database_connection_test.router)
